# HSN-Optimizations 1.9.0 (Fabric · Minecraft 26.2)

Performance addon for **pre-2015 / weak integrated GPUs**.

Full write-up: **[DESCRIPTION.md](DESCRIPTION.md)**

## Quick start

```bash
./gradlew build
# jar → build/libs/hsn-optimizations-1.9.0.jar
```

Use with **Sodium (OpenGL)** + optional **C2ME**.  
Preset **ULTRA_LOW** for Intel HD 4000/4600-class.  
JVM: `scripts/jvm-ultralow.txt` on ~4 GB RAM systems.
