# HSN-Optimizations — Modrinth checklist

## Page copy (short)

**HSN-Optimizations** is a **client-side** performance mod for **Minecraft 26.2 (Fabric)** aimed at **weak / pre-2015 GPUs** (Intel HD 4000/4600-class).

It does **not** replace Sodium. Use **Sodium or Mercurizer + HSN**.

### Features
- Particle, entity, item, XP, shadow, sound culling
- FPS quality ladder + adaptive RAM/CPU
- Color cache, block-entity distance, fog/anim throttles
- Presets: ULTRA_LOW, LOW, BALANCED, QUALITY
- **F8** ULTRA_LOW · **F9** SAFE MODE · **F7** FPS overlay
- About **Hub**: detects Sodium, Lithium, FerriteCore, C2ME, …
- JVM / G1 recommendations for 8 GB PCs
- Optional input-latency hints (raw mouse best-effort)

### Requires
- Fabric Loader
- Fabric API
- Cloth Config
- Minecraft 26.2
- Java 21+ (25 recommended)

### Suggested
- Sodium or Mercurizer
- Mod Menu
- Lithium / FerriteCore / C2ME if available for 26.2

### License
MIT (see LICENSE — update if needed)

## Upload steps
1. `.\gradlew.bat build --no-parallel`
2. Upload `build/libs/hsn-optimizations-3.4.0.jar`
3. Game versions: **26.2**
4. Loaders: **Fabric**
5. Environment: **Client**
6. Paste description from DESCRIPTION.md / this file
7. Screenshots: title + F3 with HSN line + config tabs

## Tags
`optimization` `utility` `client` `performance`
