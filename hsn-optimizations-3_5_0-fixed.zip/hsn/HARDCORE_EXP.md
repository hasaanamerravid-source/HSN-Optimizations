# HSN-Optimizations 2.2.0-hardcore

**NOT FOR RELEASE. LOCAL STRESS TEST ONLY.**

## What this build experiments with

| Experiment | What it does | Fallback |
|------------|--------------|----------|
| **Vector cull** | Tries `jdk.incubator.vector` for distance math; else scalar | Always |
| **Off-heap SoA** | Panama FFM `MemorySegment` ring of particle x/y/z | Disabled if FFM fails |
| **Lazy budget** | Recomputes particle drop rate only when RAM/CPU pressure flips | Off if disabled |

## What it does NOT do

- Multi-threaded full game tick
- Bitboard redstone
- GPU mesh shaders (HD 4600 can't)
- Voxel DAGs
- Replacing Entity with SoA (mod-breaking)

## How to test

1. `.\gradlew.bat runClient`
2. F3 under Mercurizer: `HSN EXP [HARDCORE] VEC=… SoA=… LAZY=…`
3. Config → **HARDCORE EXP** tab — toggle subsystems
4. Spam `/particle`, rain, look for crashes / FPS change
5. If crash: turn hardcore OFF, report the stack

## JVM note (optional Vector API)

If Vector stays off, try launcher JVM args:

```
--add-modules jdk.incubator.vector
```

Haswell (i5-4590) supports AVX2, not AVX-512.

## Stability policy

If a session is stable and useful, cherry-pick **individual** ideas into a normal 2.x release.
Never ship this jar labeled "release" with EXP forced on.
