package hsn.modod.client;

import hsn.modod.HSNOptimizations;
import hsn.modod.client.optimize.SmoothLightingHelper;
import hsn.modod.config.HSNConfig;
import hsn.modod.config.HSNConfig.Preset;
import hsn.modod.config.HSNPresets;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/**
 * Hotkeys via GLFW edge-detect (no KeyBindingHelper — 26.2 Fabric API safe).
 * F8 = ULTRA_LOW, F9 = SAFE MODE, F7 = FPS overlay toggle.
 */
public final class HSNKeybinds {

	private static boolean f7Down, f8Down, f9Down;

	private HSNKeybinds() {}

	public static void register() {
		ClientTickEvents.END_CLIENT_TICK.register(HSNKeybinds::onTick);
		HSNOptimizations.LOGGER.info("HSN keybinds (GLFW): F8=ULTRA_LOW, F9=SAFE, F7=FPS overlay");
	}

	private static void onTick(Minecraft client) {
		if (client == null) return;
		// Don't fire while typing in a screen with text fields if a screen is open
		// Still allow when in-game with no pause menu ideal; skip if any screen open except none
		long handle = resolveHandle(client);
		if (handle == 0L) return;

		boolean chatOpen = hsn$hasScreen(client);
		if (!chatOpen) {
			f8Down = edge(handle, GLFW.GLFW_KEY_F8, f8Down, () -> {
				HSNConfig cfg = HSNConfig.get();
				HSNPresets.apply(cfg, Preset.ULTRA_LOW);
				cfg.lastAppliedPreset = Preset.ULTRA_LOW;
				cfg.save();
				SmoothLightingHelper.applyFromConfig();
				msg(client, "HSN: applied ULTRA_LOW preset");
			});
			f9Down = edge(handle, GLFW.GLFW_KEY_F9, f9Down, () -> {
				HSNConfig cfg = HSNConfig.get();
				cfg.applySafeModeDefaults();
				cfg.save();
				SmoothLightingHelper.applyFromConfig();
				msg(client, "HSN: applied SAFE MODE");
			});
		}
		f7Down = edge(handle, GLFW.GLFW_KEY_F7, f7Down, () -> {
			HSNConfig cfg = HSNConfig.get();
			cfg.fpsOverlayEnabled = !cfg.fpsOverlayEnabled;
			cfg.save();
			msg(client, "HSN FPS overlay: " + (cfg.fpsOverlayEnabled ? "ON" : "OFF"));
		});
	}

	private static boolean edge(long handle, int key, boolean wasDown, Runnable action) {
		boolean down = GLFW.glfwGetKey(handle, key) == GLFW.GLFW_PRESS;
		if (down && !wasDown) {
			action.run();
		}
		return down;
	}

	private static long resolveHandle(Minecraft client) {
		try {
			Object win = client.getWindow();
			if (win == null) return 0L;
			for (String name : new String[]{"getHandle", "getWindow", "handle", "getGLFWWindowHandle"}) {
				try {
					Object r = win.getClass().getMethod(name).invoke(win);
					if (r instanceof Long l) return l;
					if (r instanceof Number n) return n.longValue();
				} catch (Throwable ignored) {}
			}
			for (String fname : new String[]{"handle", "window"}) {
				try {
					var f = win.getClass().getDeclaredField(fname);
					f.setAccessible(true);
					Object r = f.get(win);
					if (r instanceof Long l) return l;
					if (r instanceof Number n) return n.longValue();
				} catch (Throwable ignored) {}
			}
		} catch (Throwable ignored) {}
		return 0L;
	}

	/** 26.2-safe: Minecraft.screen was made private; try getScreen() then reflection. */
	private static boolean hsn$hasScreen(Minecraft client) {
		try {
			// 26.2 moved screen access to gui subsystem
			Object gui = client.getClass().getMethod("getGui").invoke(client);
			if (gui != null) {
				Object sc = gui.getClass().getMethod("getScreen").invoke(gui);
				if (sc != null) return true;
			}
		} catch (Throwable ignored) {}
		try {
			// Fallback: direct field access via reflection
			java.lang.reflect.Field f = client.getClass().getDeclaredField("screen");
			f.setAccessible(true);
			return f.get(client) != null;
		} catch (Throwable ignored) {}
		try {
			// Last resort: currentScreen (older mapping names)
			for (String name : new String[]{"currentScreen", "openScreen", "activeScreen"}) {
				try {
					java.lang.reflect.Field f = client.getClass().getDeclaredField(name);
					f.setAccessible(true);
					return f.get(client) != null;
				} catch (Throwable ignored2) {}
			}
		} catch (Throwable ignored) {}
		return false;
	}

	private static void msg(Minecraft client, String text) {
		HSNOptimizations.LOGGER.info(text);
		if (client.player == null) return;
		Component c = Component.literal(text);
		try {
			client.player.sendSystemMessage(c);
			return;
		} catch (Throwable ignored) {}
		try {
			for (String m : new String[]{"displayClientMessage", "sendMessage", "displayMessage"}) {
				for (Class<?> arg1 : new Class<?>[]{Component.class}) {
					try {
						client.player.getClass().getMethod(m, arg1, boolean.class).invoke(client.player, c, true);
						return;
					} catch (Throwable ignored) {}
					try {
						client.player.getClass().getMethod(m, arg1).invoke(client.player, c);
						return;
					} catch (Throwable ignored) {}
				}
			}
		} catch (Throwable ignored) {}
	}
}
