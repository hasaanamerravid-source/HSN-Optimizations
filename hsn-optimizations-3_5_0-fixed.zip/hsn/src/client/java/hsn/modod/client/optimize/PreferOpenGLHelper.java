package hsn.modod.client.optimize;

import hsn.modod.HSNOptimizations;
import hsn.modod.config.HSNConfig;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * On pre-2015 / weak iGPUs, experimental Vulkan is often unstable.
 * Ensures options.txt prefers OpenGL (matches "Prefer OpenGL" utility mods).
 */
public final class PreferOpenGLHelper {

	private PreferOpenGLHelper() {}

	public static void applyFromConfig() {
		if (!HSNConfig.get().preferOpenGl) return;

		Path options = FabricLoader.getInstance().getGameDir().resolve("options.txt");
		try {
			List<String> lines = Files.exists(options)
					? Files.readAllLines(options, StandardCharsets.UTF_8)
					: new ArrayList<>();

			boolean found = false;
			for (int i = 0; i < lines.size(); i++) {
				String line = lines.get(i);
				if (line.startsWith("graphicsApiPreference:")
						|| line.startsWith("graphicsApi:")) {
					lines.set(i, "graphicsApiPreference:prefer_opengl");
					found = true;
				}
			}
			if (!found) {
				lines.add("graphicsApiPreference:prefer_opengl");
			}

			Files.write(options, lines, StandardCharsets.UTF_8);
			HSNOptimizations.LOGGER.info("Prefer OpenGL written to options.txt (safer on pre-2015 GPUs)");
		} catch (Exception e) {
			HSNOptimizations.LOGGER.warn("Could not set prefer OpenGL: {}", e.toString());
		}
	}
}
