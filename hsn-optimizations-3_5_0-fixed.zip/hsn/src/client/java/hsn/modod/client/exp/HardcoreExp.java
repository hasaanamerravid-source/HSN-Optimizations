package hsn.modod.client.exp;

import hsn.modod.HSNOptimizations;
import hsn.modod.config.HSNConfig;

/**
 * HARDCORE EXPERIMENTAL runtime — not for release builds.
 * Probes how far low-level client paths can go on weak hardware.
 * Every subsystem fails soft and falls back to stable HSN logic.
 */
public final class HardcoreExp {

	private static boolean active = false;
	private static String statusLine = "HSN EXP: off";

	private HardcoreExp() {}

	public static void init() {
		HSNConfig cfg = HSNConfig.get();
		if (!cfg.hardcoreExpEnabled) {
			active = false;
			statusLine = "HSN EXP: off";
			HSNOptimizations.LOGGER.info("Hardcore EXP disabled (stable path only)");
			return;
		}

		active = true;
		StringBuilder sb = new StringBuilder("HSN EXP [HARDCORE]");

		boolean vec = VectorCull.tryInit();
		sb.append(vec ? " VEC=on" : " VEC=off");

		boolean soa = OffHeapParticleSoA.tryInit(cfg.offHeapParticleCapacity);
		sb.append(soa ? " SoA=on" : " SoA=off");

		boolean lazy = LazyBudget.tryInit();
		sb.append(lazy ? " LAZY=on" : " LAZY=off");

		statusLine = sb.toString();
		HSNOptimizations.LOGGER.warn("=== HARDCORE EXPERIMENTAL MODE ===");
		HSNOptimizations.LOGGER.warn("{}", statusLine);
		HSNOptimizations.LOGGER.warn("NOT FOR RELEASE. Worlds/mods may behave oddly. Report crashes.");
	}

	public static boolean isActive() {
		return active && HSNConfig.get().hardcoreExpEnabled;
	}

	public static String f3Line() {
		if (!isActive()) return "HSN-Optimizations 2.2.0-hardcore (EXP off)";
		return statusLine + " | " + OffHeapParticleSoA.stats() + " | " + LazyBudget.stats();
	}

	/** Fast reject: true = cull (do not spawn). */
	public static boolean shouldCullParticle(double x, double y, double z, double maxDistSq) {
		if (!isActive()) return false;

		HSNConfig cfg = HSNConfig.get();

		// Lazy budget: under pressure, cull more aggressively by random
		if (cfg.hardcoreLazyBudget && LazyBudget.shouldDrop()) {
			return true;
		}

		// Vector / batch-style distance (or scalar fallback inside VectorCull)
		if (cfg.hardcoreVectorCull && VectorCull.beyondDistance(x, y, z, maxDistSq)) {
			return true;
		}

		// Track in off-heap SoA if enabled (does not itself cull)
		if (cfg.hardcoreOffHeapSoa) {
			OffHeapParticleSoA.record(x, y, z);
		}

		return false;
	}
}
