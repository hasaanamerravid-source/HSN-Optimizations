package hsn.modod.client.optimize;

import hsn.modod.client.compat.StackHub;
import hsn.modod.config.HSNConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;

/**
 * FPS badge state + draw helper. Rendering hooked from GuiMixin (26.2-safe).
 */
public final class FpsOverlay {

	private FpsOverlay() {}

	/** No-op: draw is invoked from GuiMixin. */
	public static void register() {
		// intentionally empty — see GuiMixin
	}

	public static void tryDraw(Object guiGraphics) {
		HSNConfig cfg = HSNConfig.get();
		if (!cfg.fpsOverlayEnabled) return;
		Minecraft mc = Minecraft.getInstance();
		if (mc == null) return;
		if (isHideGui(mc)) return;

		int fps = 0;
		try {
			fps = mc.getFps();
		} catch (Throwable ignored) {
			try {
				Object f = mc.getClass().getMethod("getFps").invoke(mc);
				if (f instanceof Number n) fps = n.intValue();
			} catch (Throwable ignored2) {}
		}

		String line = "HSN " + fps + " FPS | " + FpsQualityLadder.f3();
		if (cfg.fpsOverlayShowStack) {
			line = line + " | " + shortStack();
		}

		try {
			Font font = mc.font;
			int x = cfg.fpsOverlayX;
			int y = cfg.fpsOverlayY;
			int color = 0xFFE0E0E0;
			try {
				guiGraphics.getClass()
						.getMethod("drawString", Font.class, String.class, int.class, int.class, int.class, boolean.class)
						.invoke(guiGraphics, font, line, x, y, color, true);
			} catch (Throwable t1) {
				try {
					guiGraphics.getClass()
							.getMethod("drawString", Font.class, String.class, int.class, int.class, int.class)
							.invoke(guiGraphics, font, line, x, y, color);
				} catch (Throwable ignored) {}
			}
		} catch (Throwable ignored) {}
	}

	private static boolean isHideGui(Minecraft mc) {
		try {
			Object opt = mc.options;
			for (String name : new String[]{"hideGui", "hideHud", "hideGUI"}) {
				try {
					Object f = opt.getClass().getField(name).get(opt);
					if (f instanceof Boolean b) return b;
					try {
						Object v = f.getClass().getMethod("get").invoke(f);
						if (v instanceof Boolean b) return b;
					} catch (Throwable ignored) {}
				} catch (Throwable ignored) {}
			}
		} catch (Throwable ignored) {}
		return false;
	}

	private static String shortStack() {
		StringBuilder sb = new StringBuilder();
		if (StackHub.loaded("sodium") || StackHub.loaded("mercurizer") || StackHub.loaded("embeddium")) {
			sb.append("Na+");
		}
		if (StackHub.loaded("lithium")) sb.append("Li+");
		if (sb.isEmpty()) sb.append("van");
		return sb.toString();
	}
}
