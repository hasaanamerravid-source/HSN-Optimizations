package hsn.modod.client.exp;

import hsn.modod.client.optimize.AdaptivePerformance;
import hsn.modod.config.HSNConfig;

/**
 * Event-ish particle budget: when adaptive pressure flips, tighten drop rate
 * without re-evaluating every particle the same way.
 */
public final class LazyBudget {

	private static double dropChance = 0.0;
	private static boolean ready = false;
	private static int lastPressureBits = -1;

	private LazyBudget() {}

	public static boolean tryInit() {
		ready = true;
		dropChance = 0.0;
		return true;
	}

	public static void tick() {
		if (!ready || !HSNConfig.get().hardcoreLazyBudget) return;
		int bits = (AdaptivePerformance.isRamPressure() ? 1 : 0) | (AdaptivePerformance.isCpuPressure() ? 2 : 0);
		if (bits == lastPressureBits) return; // lazy: only recompute on change
		lastPressureBits = bits;
		if (bits == 0) dropChance = 0.0;
		else if (bits == 3) dropChance = 0.55;
		else dropChance = 0.30;
	}

	public static boolean shouldDrop() {
		if (!ready) return false;
		tick();
		return dropChance > 0 && Math.random() < dropChance;
	}

	public static String stats() {
		return "lazyDrop=" + String.format("%.0f%%", dropChance * 100);
	}
}
