package hsn.modod.client.mixin;

import hsn.modod.client.optimize.AdaptivePerformance;
import hsn.modod.client.optimize.FpsQualityLadder;
import hsn.modod.config.HSNConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Cancels cloud rendering when FPS ladder is at level ≥ 2 (aggressive) OR
 * when both RAM and CPU pressure are detected simultaneously. At FPS ladder
 * level 1 clouds render every other tick instead of every tick (half the draw
 * calls, same visual since clouds move slowly).
 *
 * Soft target (require = 0) — cloud rendering moved into LevelRenderer's
 * renderClouds in 1.17+ but the method name drift differs across versions.
 */
@Mixin(targets = {
		"net.minecraft.client.renderer.LevelRenderer",
		"net.minecraft.client.render.WorldRenderer"
}, priority = 900)
public class CloudRendererMixin {

	@Inject(
			method = {
					"renderClouds",
					"renderCloudLayer",
					"drawClouds"
			},
			at = @At("HEAD"),
			cancellable = true,
			require = 0
	)
	private void hsn$throttleClouds(CallbackInfo ci) {
		HSNConfig cfg = HSNConfig.get();
		if (!cfg.cloudReductionEnabled) return;

		int level = FpsQualityLadder.level();
		boolean ramPressure = AdaptivePerformance.isRamPressure();
		boolean cpuPressure = AdaptivePerformance.isCpuPressure();

		if (level >= 2 || (ramPressure && cpuPressure)) {
			// Fully skip cloud render this frame
			ci.cancel();
		} else if (level >= 1) {
			// Render every other tick (clouds move at ~1 block/sec so imperceptible)
			if ((System.nanoTime() & 1L) == 0L) {
				ci.cancel();
			}
		}
	}
}
