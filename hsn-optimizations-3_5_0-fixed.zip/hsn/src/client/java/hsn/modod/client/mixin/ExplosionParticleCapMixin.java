package hsn.modod.client.mixin;

import hsn.modod.config.HSNConfig;
import net.minecraft.client.particle.ParticleEngine;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Caps the number of particles spawned per explosion event.
 *
 * The global max-particles cap in ParticleManagerMixin handles total concurrent
 * particles. But a single large explosion can still spike the particle engine
 * with hundreds of particles in one frame (before the cap reacts). This mixin
 * adds a per-burst counter reset: when a createExplosion / handleExplosion-style
 * method fires, we note the pre-burst particle count and short-circuit creation
 * once per-explosion budget is exhausted.
 *
 * Soft-target (require = 0) because explosion method names differ between
 * vanilla 26.2 and any Sodium/Embeddium particle-pool patches.
 */
@Mixin(value = ParticleEngine.class, priority = 990)
public class ExplosionParticleCapMixin {

	@Unique
	private static int hsn$explosionBurstCount = 0;
	@Unique
	private static long hsn$explosionFrameId = -1L;

	/**
	 * Called on each particle creation. When the global frame id changes (new
	 * tick / new burst) the counter resets. Once the per-explosion budget is
	 * hit, all subsequent particles from that burst are dropped.
	 */
	@Inject(
			method = "createParticle(Lnet/minecraft/core/particles/ParticleOptions;DDDDDD)Lnet/minecraft/client/particle/Particle;",
			at = @At("HEAD"),
			cancellable = true,
			require = 0
	)
	private void hsn$explosionCap(
			net.minecraft.core.particles.ParticleOptions options,
			double x, double y, double z,
			double xSpeed, double ySpeed, double zSpeed,
			org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable<?> cir
	) {
		HSNConfig cfg = HSNConfig.get();
		if (!cfg.explosionParticleCapEnabled) return;

		var type = options.getType();
		if (!hsn$isExplosionType(type)) return;

		// Use wall-clock nanos as a "burst epoch" — resets each time ≥ 5ms
		// passes between consecutive explosion particles (i.e. a new event).
		long now = System.nanoTime();
		if (now - hsn$explosionFrameId > 5_000_000L) { // 5 ms gap = new explosion
			hsn$explosionBurstCount = 0;
		}
		hsn$explosionFrameId = now;
		hsn$explosionBurstCount++;

		if (hsn$explosionBurstCount > Math.max(10, cfg.maxParticlesPerExplosion)) {
			cir.setReturnValue(null);
		}
	}

	private static boolean hsn$isExplosionType(Object type) {
		if (type == null) return false;
		try {
			var pt = net.minecraft.core.particles.ParticleTypes.class;
			if (type == pt.getField("EXPLOSION").get(null)) return true;
			if (type == pt.getField("EXPLOSION_EMITTER").get(null)) return true;
			if (type == pt.getField("POOF").get(null)) return true;
		} catch (Throwable ignored) {}
		String s = type.toString().toLowerCase();
		return s.contains("explosion") || s.contains("poof");
	}

	@Inject(method = "tick", at = @At("HEAD"), require = 0)
	private void hsn$resetBurstOnTick(CallbackInfo ci) {
		// Full reset every tick so multi-explosion events in the same world
		// tick each get their own budget rather than sharing one counter.
		hsn$explosionBurstCount = 0;
		hsn$explosionFrameId = -1L;
	}
}
