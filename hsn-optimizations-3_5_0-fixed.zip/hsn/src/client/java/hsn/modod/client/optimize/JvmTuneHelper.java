package hsn.modod.client.optimize;

import hsn.modod.HSNOptimizations;
import hsn.modod.config.HSNConfig;

import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Computes safe Xms/Xmx / GC recommendations for weak PCs.
 * Cannot change the running JVM's max heap; writes a helper file + logs.
 */
public final class JvmTuneHelper {

	private JvmTuneHelper() {}

	public static void init() {
		HSNConfig cfg = HSNConfig.get();
		if (!cfg.jvmTuneHintsEnabled) return;

		long hostMb = detectHostRamMb();
		int xmx = pickXmx(hostMb, cfg.recommendedXmxMb);
		int xms = Math.min(xmx, Math.max(256, xmx / 2));

		String flags = String.join(" ",
				"-Xms" + xms + "M",
				"-Xmx" + xmx + "M",
				"-XX:+UseG1GC",
				"-XX:MaxGCPauseMillis=50",
				"-XX:+ParallelRefProcEnabled",
				"-XX:G1HeapRegionSize=8M",
				"-XX:+UnlockExperimentalVMOptions",
				"-XX:G1NewSizePercent=20",
				"-XX:G1MaxNewSizePercent=40",
				"-XX:InitiatingHeapOccupancyPercent=35",
				"-XX:G1MixedGCLiveThresholdPercent=50"
		);

		HSNOptimizations.LOGGER.info("=== HSN JVM recommendations (host ~{} MB) ===", hostMb);
		HSNOptimizations.LOGGER.info("Suggested flags: {}", flags);
		HSNOptimizations.LOGGER.info("Apply in launcher JVM args, then restart. Live heap cannot be resized by the mod.");

		try {
			Path out = Path.of("hsn-jvm-recommended.txt");
			Files.writeString(out,
					"# HSN-Optimizations recommended JVM flags\n" +
					"# Host RAM estimate: " + hostMb + " MB\n" +
					"# Paste into your launcher / IntelliJ run config, then restart.\n\n" +
					flags + "\n");
		} catch (Throwable t) {
			HSNOptimizations.LOGGER.debug("Could not write hsn-jvm-recommended.txt: {}", t.toString());
		}
	}

	public static long detectHostRamMb() {
		try {
			com.sun.management.OperatingSystemMXBean os =
					(com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
			long bytes = os.getTotalMemorySize();
			if (bytes > 0) return bytes / (1024 * 1024);
		} catch (Throwable ignored) {}
		try {
			MemoryMXBean mem = ManagementFactory.getMemoryMXBean();
			long max = mem.getHeapMemoryUsage().getMax();
			if (max > 0) return Math.max(2048, max / (1024 * 1024) * 2);
		} catch (Throwable ignored) {}
		return 8192;
	}

	/** Conservative Xmx for 8 GB and weaker boxes. */
	public static int pickXmx(long hostMb, int userPref) {
		int cap;
		if (hostMb <= 4096) cap = 1536;
		else if (hostMb <= 6144) cap = 2048;
		else if (hostMb <= 8192) cap = 3072;
		else if (hostMb <= 12288) cap = 4096;
		else cap = 6144;
		int pref = Math.max(512, Math.min(userPref, 8192));
		return Math.min(cap, pref);
	}

	public static void softGcIfEnabled() {
		if (!HSNConfig.get().softGcOnIdlePressure) return;
		if (!AdaptivePerformance.isRamPressure()) return;
		try {
			System.gc();
		} catch (Throwable ignored) {}
	}

	public static String summaryLine() {
		long host = detectHostRamMb();
		int xmx = pickXmx(host, HSNConfig.get().recommendedXmxMb);
		return "HSN JVM hint: host~" + host + "MB → Xmx" + xmx + "M G1";
	}
}
