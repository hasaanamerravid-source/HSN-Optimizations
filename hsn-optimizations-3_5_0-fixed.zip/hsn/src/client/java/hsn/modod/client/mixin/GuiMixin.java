package hsn.modod.client.mixin;

import hsn.modod.client.optimize.FpsOverlay;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(
		targets = {
				"net.minecraft.client.gui.Gui",
				"net.minecraft.client.gui.hud.InGameHud"
		},
		priority = 1100
)
public class GuiMixin {

	/**
	 * Catch common Gui.render signatures; first arg is draw context when present.
	 */
	@Inject(method = "render", at = @At("RETURN"), require = 0)
	private void hsn$overlay(CallbackInfo ci) {
		// Signature without graphics — cannot draw; no-op
	}

	@Inject(method = "render", at = @At("RETURN"), require = 0)
	private void hsn$overlay2(Object a, Object b, CallbackInfo ci) {
		if (a != null && a.getClass().getName().toLowerCase().contains("gui")) {
			FpsOverlay.tryDraw(a);
		} else if (a != null && a.getClass().getName().toLowerCase().contains("draw")) {
			FpsOverlay.tryDraw(a);
		} else if (a != null) {
			FpsOverlay.tryDraw(a);
		}
	}

	@Inject(method = "render", at = @At("RETURN"), require = 0)
	private void hsn$overlay3(Object a, CallbackInfo ci) {
		if (a != null) FpsOverlay.tryDraw(a);
	}
}
