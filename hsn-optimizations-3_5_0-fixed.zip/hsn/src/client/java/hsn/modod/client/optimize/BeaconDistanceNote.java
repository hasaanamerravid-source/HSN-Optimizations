package hsn.modod.client.optimize;

/**
 * Beacon beam distance culling needs a stable BeaconRenderer.render signature on 26.2.
 * Config options remain; renderer mixin will be re-added when mappings are confirmed.
 * (Beacon still benefits from entity/chunk distance + Sodium.)
 */
public final class BeaconDistanceNote {
	private BeaconDistanceNote() {}
}
