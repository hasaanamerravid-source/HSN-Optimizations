package hsn.modod.client.mixin;

import hsn.modod.client.optimize.AdaptivePerformance;
import hsn.modod.client.optimize.FpsQualityLadder;
import hsn.modod.config.HSNConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Skip some animated texture frame advances under load (water/lava/portal-style atlas animations).
 */
@Mixin(targets = {
		"net.minecraft.client.renderer.texture.TextureAtlasSprite$AnimatedTexture",
		"net.minecraft.client.texture.SpriteContents$Animator",
		"net.minecraft.client.renderer.texture.SpriteContents$AnimatedTexture"
}, priority = 900)
public class AnimatedTextureMixin {

	@Inject(method = {"tick", "uploadFrames", "cycleFrames"}, at = @At("HEAD"), cancellable = true, require = 0)
	private void hsn$throttleAnim(CallbackInfo ci) {
		if (!HSNConfig.get().reduceAnimatedTextures) return;
		int level = FpsQualityLadder.level();
		boolean pressure = AdaptivePerformance.isCpuPressure() || AdaptivePerformance.isRamPressure();
		if (level >= 2 || (level >= 1 && pressure)) {
			// skip ~half of ticks
			if ((System.nanoTime() & 1L) == 0L) {
				ci.cancel();
			}
		} else if (level >= 1 && (System.nanoTime() % 3L) == 0L) {
			ci.cancel();
		}
	}
}
