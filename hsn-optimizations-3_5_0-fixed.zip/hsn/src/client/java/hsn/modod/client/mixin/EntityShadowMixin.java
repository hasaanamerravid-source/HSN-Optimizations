package hsn.modod.client.mixin;

import hsn.modod.client.optimize.AdaptivePerformance;
import hsn.modod.config.HSNConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Cancels entity shadow drawing when the entity is farther than maxShadowDistance.
 * Method matching is soft (require = 0) so a signature drift on 26.2 does not crash the game.
 */
@Mixin(EntityRenderDispatcher.class)
public class EntityShadowMixin {

	@Inject(method = "renderShadow", at = @At("HEAD"), cancellable = true, require = 0)
	private static void hsn$cullShadowStatic(CallbackInfo ci) {
		// Fallback no-arg path — rarely used; real work is entity-aware inject below
	}

	/**
	 * Common Mojmap-style signature (entity is present so we can distance-check).
	 * If this method does not exist, Mixin skips it because require = 0.
	 */
	@Inject(
			method = "renderShadow(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;Lnet/minecraft/world/entity/Entity;FFLnet/minecraft/world/level/LevelReader;F)V",
			at = @At("HEAD"),
			cancellable = true,
			require = 0
	)
	private void hsn$cullShadowEntity(
			Object poseStack,
			Object buffer,
			Entity entity,
			float opacity,
			float tickDelta,
			Object level,
			float radius,
			CallbackInfo ci
	) {
		if (isTooFar(entity)) {
			ci.cancel();
		}
	}

	/** Alternate shorter overload used on some builds */
	@Inject(
			method = "renderShadow(Lnet/minecraft/world/entity/Entity;FF)V",
			at = @At("HEAD"),
			cancellable = true,
			require = 0
	)
	private void hsn$cullShadowShort(Entity entity, float a, float b, CallbackInfo ci) {
		if (isTooFar(entity)) {
			ci.cancel();
		}
	}

	private static boolean isTooFar(Entity entity) {
		HSNConfig cfg = HSNConfig.get();
		if (!cfg.shadowCullingEnabled || entity == null) return false;

		Minecraft client = Minecraft.getInstance();
		Player player = client.player;
		if (player == null) return false;
		if (entity == player) return false; // always show local player shadow

		double dx = entity.getX() - player.getX();
		double dy = entity.getY() - player.getY();
		double dz = entity.getZ() - player.getZ();
		return dx * dx + dy * dy + dz * dz > AdaptivePerformance.effectiveShadowDistanceSq();
	}
}
