package hsn.modod.client.mixin;

import hsn.modod.client.optimize.FpsQualityLadder;
import hsn.modod.config.HSNConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Shorten fog end distance when FPS ladder is elevated — less far-plane fill on weak iGPUs.
 */
@Mixin(targets = {
		"net.minecraft.client.renderer.FogRenderer",
		"net.minecraft.client.render.BackgroundRenderer",
		"net.minecraft.client.renderer.FogRenderer$FogData"
}, priority = 900)
public class FogRendererMixin {

	@ModifyVariable(
			method = {
					"setupFog",
					"applyFog",
					"getFogColor"
			},
			at = @At("HEAD"),
			argsOnly = true,
			ordinal = 0,
			require = 0
	)
	private static float hsn$scaleFog(float value) {
		// Only scale if it looks like a distance (heuristic); may no-op on wrong signature
		if (!HSNConfig.get().fogLadderEnabled) return value;
		double f = FpsQualityLadder.distanceFactor();
		if (f >= 0.99) return value;
		if (value > 8.0f && value < 512.0f) {
			return (float) (value * f);
		}
		return value;
	}
}
