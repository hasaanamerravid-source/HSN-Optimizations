package hsn.modod.client.mixin;

import hsn.modod.config.HSNConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.sounds.SoundEngine;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * play() returns a value on 26.2 → must use CallbackInfoReturnable.
 */
@Mixin(SoundEngine.class)
public class SoundEngineMixin {

	@Inject(method = "play", at = @At("HEAD"), cancellable = true, require = 0)
	private void hsn$soundCull(SoundInstance sound, CallbackInfoReturnable<?> cir) {
		HSNConfig cfg = HSNConfig.get();
		if (!cfg.soundDistanceCullingEnabled && !cfg.weatherSoundReductionEnabled) return;
		if (sound == null) return;

		String path = hsn$pathOf(sound);

		if (path.contains("ui") || path.contains("music") || path.contains("menu")
				|| path.contains("click") || path.contains("note")) {
			return;
		}

		boolean weather = path.contains("rain") || path.contains("thunder")
				|| path.contains("weather");

		if (weather && cfg.weatherSoundReductionEnabled) {
			if (Math.random() > cfg.weatherSoundKeepChance) {
				cir.setReturnValue(null);
				return;
			}
		}

		if (!cfg.soundDistanceCullingEnabled) return;

		try {
			if (sound.isRelative()) return;
		} catch (Throwable ignored) {}

		Player player = Minecraft.getInstance().player;
		if (player == null) return;

		double[] pos = hsn$posOf(sound);
		if (pos == null) return;

		double dx = pos[0] - player.getX();
		double dy = pos[1] - player.getY();
		double dz = pos[2] - player.getZ();
		if (dx * dx + dy * dy + dz * dz > cfg.maxSoundDistanceSq()) {
			cir.setReturnValue(null);
		}
	}

	private static String hsn$pathOf(SoundInstance sound) {
		try {
			for (String m : new String[]{"getLocation", "getIdentifier", "location", "getSoundLocation", "getSoundEvent"}) {
				try {
					Object id = sound.getClass().getMethod(m).invoke(sound);
					if (id != null) {
						try {
							Object p = id.getClass().getMethod("getPath").invoke(id);
							if (p != null) return p.toString().toLowerCase();
						} catch (Throwable ignored) {}
						return id.toString().toLowerCase();
					}
				} catch (Throwable ignored) {}
			}
		} catch (Throwable ignored) {}
		return sound.toString().toLowerCase();
	}

	private static double[] hsn$posOf(SoundInstance sound) {
		try {
			double x = ((Number) sound.getClass().getMethod("getX").invoke(sound)).doubleValue();
			double y = ((Number) sound.getClass().getMethod("getY").invoke(sound)).doubleValue();
			double z = ((Number) sound.getClass().getMethod("getZ").invoke(sound)).doubleValue();
			return new double[]{x, y, z};
		} catch (Throwable t) {
			return null;
		}
	}
}
