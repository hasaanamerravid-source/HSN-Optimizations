package hsn.modod.client.mixin;

import hsn.modod.config.HSNConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Reduce cumulative mouse filtering when low-latency mode is on (soft targets).
 */
@Mixin(targets = {
		"net.minecraft.client.MouseHandler",
		"net.minecraft.client.mouse.Mouse"
}, priority = 900)
public class MouseHandlerMixin {

	@Inject(method = {"onMove", "turnPlayer", "updateMouse"}, at = @At("HEAD"), require = 0)
	private void hsn$latencyMark(CallbackInfo ci) {
		// Marker only — actual raw mouse is GLFW in InputLatencyHelper.
		// Kept so future hooks can short-circuit smoothing accumulators if mapped.
		if (!HSNConfig.get().inputLatencyEnabled) return;
	}
}
