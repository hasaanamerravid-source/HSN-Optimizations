package hsn.modod.client.optimize;

import hsn.modod.config.HSNConfig;
import net.minecraft.client.Minecraft;

/** Nudges vanilla cloud option off when ladder is high and skyCloudLadderEnabled. */
public final class SkyFogHelper {

	private static int lastLevel = -1;

	private SkyFogHelper() {}

	public static void tick(Minecraft client) {
		if (!HSNConfig.get().skyCloudLadderEnabled || client == null) return;
		int level = FpsQualityLadder.level();
		if (level == lastLevel) return;
		lastLevel = level;
		if (level < 1) return;
		try {
			Object options = client.options;
			if (options == null) return;
			// Best-effort: clouds off under load
			for (String name : new String[]{"cloudStatus", "clouds", "getCloudStatus"}) {
				try {
					Object fieldOrMethod = null;
					try {
						fieldOrMethod = options.getClass().getField(name).get(options);
					} catch (Throwable t) {
						fieldOrMethod = options.getClass().getMethod(name).invoke(options);
					}
					if (fieldOrMethod != null) {
						for (String set : new String[]{"set", "setValue"}) {
							try {
								// enum OFF if present
								Object off = null;
								for (Object c : fieldOrMethod.getClass().getEnumConstants() != null
										? fieldOrMethod.getClass().getEnumConstants()
										: new Object[0]) {
									if (c.toString().toUpperCase().contains("OFF")
											|| c.toString().toUpperCase().contains("FALSE")) {
										off = c;
										break;
									}
								}
								if (off != null) {
									fieldOrMethod.getClass().getMethod(set, off.getClass()).invoke(fieldOrMethod, off);
								}
							} catch (Throwable ignored) {}
						}
					}
				} catch (Throwable ignored) {}
			}
		} catch (Throwable ignored) {}
	}
}
