package hsn.modod.client.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Disabled vanilla video-settings button; use Sodium tab / Mod Menu. */
@Mixin(
		targets = {
				"net.minecraft.client.gui.screens.options.VideoSettingsScreen",
				"net.minecraft.client.gui.screens.VideoSettingsScreen"
		},
		priority = 900
)
public abstract class VideoSettingsScreenMixin {
	@Inject(method = "init", at = @At("RETURN"), require = 0)
	private void hsn$noop(CallbackInfo ci) {}
}
