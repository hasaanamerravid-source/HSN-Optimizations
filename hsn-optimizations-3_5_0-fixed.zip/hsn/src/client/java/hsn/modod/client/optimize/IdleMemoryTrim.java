package hsn.modod.client.optimize;

import hsn.modod.HSNOptimizations;
import hsn.modod.config.HSNConfig;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

/**
 * Opt-in idle memory trim. Only runs System.gc() after the player has been
 * truly idle for a configurable number of seconds, and respects a cooldown.
 * Mirrors the safety pattern used by dedicated "Memory Cleaner" mods —
 * never force-GC while the player is active.
 */
public final class IdleMemoryTrim {

	private static int idleTicks = 0;
	private static int cooldownTicks = 0;
	private static double lastX, lastY, lastZ;
	private static float lastYRot, lastXRot;
	private static boolean hasLast = false;

	private IdleMemoryTrim() {}

	public static void init() {
		ClientTickEvents.END_CLIENT_TICK.register(IdleMemoryTrim::onClientTick);
	}

	private static void onClientTick(Minecraft client) {
		HSNConfig cfg = HSNConfig.get();
		if (!cfg.idleMemoryTrimEnabled) {
			idleTicks = 0;
			return;
		}

		if (cooldownTicks > 0) {
			cooldownTicks--;
		}

		LocalPlayer player = client.player;
		if (player == null || client.level == null || client.isPaused()) {
			idleTicks = 0;
			hasLast = false;
			return;
		}

		double x = player.getX();
		double y = player.getY();
		double z = player.getZ();
		float yRot = player.getYRot();
		float xRot = player.getXRot();

		boolean moved = false;
		if (hasLast) {
			double dx = x - lastX, dy = y - lastY, dz = z - lastZ;
			if (dx * dx + dy * dy + dz * dz > 0.0001
					|| Math.abs(yRot - lastYRot) > 0.1f
					|| Math.abs(xRot - lastXRot) > 0.1f) {
				moved = true;
			}
		}

		lastX = x; lastY = y; lastZ = z;
		lastYRot = yRot; lastXRot = xRot;
		hasLast = true;

		if (moved) {
			idleTicks = 0;
			return;
		}

		idleTicks++;
		int needed = cfg.idleSecondsBeforeTrim * 20;
		if (idleTicks >= needed && cooldownTicks <= 0) {
			HSNOptimizations.LOGGER.info("Idle memory trim: requesting GC after {}s idle",
					cfg.idleSecondsBeforeTrim);
			System.gc();
			idleTicks = 0;
			cooldownTicks = cfg.memoryTrimCooldownSeconds * 20;
		}
	}
}
