package hsn.modod.client.mixin;

import hsn.modod.config.HSNConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Optional: reduce client tick rate for far living entities (animation/CPU relief).
 * Default OFF — enable in config. Never applies to the local player.
 */
@Mixin(LivingEntity.class)
public class DistantEntityTickMixin {

	@Inject(method = "tick", at = @At("HEAD"), cancellable = true, require = 0)
	private void hsn$distantAnimSkip(CallbackInfo ci) {
		HSNConfig cfg = HSNConfig.get();
		if (!cfg.distantAnimationSkipEnabled) return;

		LivingEntity self = (LivingEntity) (Object) this;
		Minecraft client = Minecraft.getInstance();
		if (client.level == null || !client.level.isClientSide()) return;
		if (self instanceof Player) return; // never skip players (SMP-safe)

		Player player = client.player;
		if (player == null) return;

		double dx = self.getX() - player.getX();
		double dy = self.getY() - player.getY();
		double dz = self.getZ() - player.getZ();
		if (dx * dx + dy * dy + dz * dz < cfg.distantAnimationDistanceSq()) return;

		int interval = Math.max(2, cfg.distantAnimationTickInterval);
		if (self.tickCount % interval != 0) {
			ci.cancel();
		}
	}
}
