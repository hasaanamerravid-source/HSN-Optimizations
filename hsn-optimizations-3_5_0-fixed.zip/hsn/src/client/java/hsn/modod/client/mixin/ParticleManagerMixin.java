package hsn.modod.client.mixin;

import hsn.modod.client.optimize.AdaptivePerformance;
import hsn.modod.client.exp.HardcoreExp;
import hsn.modod.config.HSNConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleEngine;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.concurrent.atomic.AtomicInteger;

@Mixin(ParticleEngine.class)
public class ParticleManagerMixin {

	@Unique
	private static final AtomicInteger particleCounter = new AtomicInteger(0);

	@Inject(
			method = "createParticle(Lnet/minecraft/core/particles/ParticleOptions;DDDDDD)Lnet/minecraft/client/particle/Particle;",
			at = @At("HEAD"),
			cancellable = true
	)
	private void hsn$cullParticle(
			ParticleOptions options,
			double x, double y, double z,
			double xSpeed, double ySpeed, double zSpeed,
			CallbackInfoReturnable<Particle> cir
	) {
		HSNConfig cfg = HSNConfig.get();
		if (!cfg.particleCullingEnabled) return;

		// HARDCORE EXP: vector / SoA / lazy paths (fail-soft)
		if (HardcoreExp.isActive()) {
			double maxSq = cfg.maxParticleDistanceSq();
			if (HardcoreExp.shouldCullParticle(x, y, z, maxSq)) {
				cir.setReturnValue(null);
				return;
			}
		}

		var type = options.getType();

		// Biome ambient particles (spore, ash, drip, etc.)
		if (cfg.biomeParticleExtraCullEnabled && hsn$isBiomeAmbient(type)) {
			if (Math.random() > cfg.biomeParticleKeepChance) {
				cir.setReturnValue(null);
				return;
			}
		}


		if (type == ParticleTypes.RAIN || type == ParticleTypes.SPLASH || type == ParticleTypes.FISHING) {
			if (Math.random() > cfg.rainKeepChance) {
				cir.setReturnValue(null);
				return;
			}
		}

		if (type == ParticleTypes.CAMPFIRE_COSY_SMOKE
				|| type == ParticleTypes.CAMPFIRE_SIGNAL_SMOKE
				|| type == ParticleTypes.CLOUD
				|| type == ParticleTypes.LARGE_SMOKE
				|| type == ParticleTypes.SMOKE) {
			if (Math.random() > cfg.smokeKeepChance) {
				cir.setReturnValue(null);
				return;
			}
		}

		if (cfg.lightParticleCullingEnabled) {
			if (type == ParticleTypes.END_ROD
					|| type == ParticleTypes.GLOW
					|| type == ParticleTypes.GLOW_SQUID_INK
					|| type == ParticleTypes.ELECTRIC_SPARK
					|| type == ParticleTypes.SCRAPE
					|| type == ParticleTypes.WAX_ON
					|| type == ParticleTypes.WAX_OFF
					|| type == ParticleTypes.FIREFLY
					|| type == ParticleTypes.SOUL_FIRE_FLAME
					|| type == ParticleTypes.SOUL
					|| type == ParticleTypes.FLAME
					|| type == ParticleTypes.SMALL_FLAME) {
				if (Math.random() > cfg.lightParticleKeepChance) {
					cir.setReturnValue(null);
					return;
				}
			}
		}

		if (type == ParticleTypes.EXPLOSION
				|| type == ParticleTypes.EXPLOSION_EMITTER
				|| type == ParticleTypes.POOF
				|| type == ParticleTypes.PORTAL
				|| type == ParticleTypes.REVERSE_PORTAL
				|| type == ParticleTypes.TOTEM_OF_UNDYING
				|| type == ParticleTypes.FIREWORK
				|| type == ParticleTypes.FLASH
				|| type == ParticleTypes.ASH
				|| type == ParticleTypes.WHITE_ASH
				|| type == ParticleTypes.SPORE_BLOSSOM_AIR
				|| type == ParticleTypes.DRIPPING_WATER
				|| type == ParticleTypes.DRIPPING_LAVA
				|| type == ParticleTypes.FALLING_WATER
				|| type == ParticleTypes.FALLING_LAVA
				|| type == ParticleTypes.DRIPPING_OBSIDIAN_TEAR
				|| type == ParticleTypes.FALLING_OBSIDIAN_TEAR
				|| type == ParticleTypes.LANDING_OBSIDIAN_TEAR
				|| type == ParticleTypes.CHERRY_LEAVES
				|| type == ParticleTypes.EGG_CRACK
				|| type == ParticleTypes.GUST
				|| type == ParticleTypes.GUST_EMITTER_LARGE
				|| type == ParticleTypes.GUST_EMITTER_SMALL) {
			if (Math.random() > cfg.heavyParticleKeepChance) {
				cir.setReturnValue(null);
				return;
			}
		}

		int max = AdaptivePerformance.effectiveMaxParticles();
		if (particleCounter.get() >= max) {
			cir.setReturnValue(null);
			return;
		}

		Minecraft client = Minecraft.getInstance();
		Player player = client.player;
		if (player != null) {
			double dx = x - player.getX();
			double dy = y - player.getY();
			double dz = z - player.getZ();
			if (dx * dx + dy * dy + dz * dz > cfg.maxParticleDistanceSq()) {
				cir.setReturnValue(null);
				return;
			}
		}

		particleCounter.incrementAndGet();
	}

	@Inject(method = "tick", at = @At("HEAD"))
	private void hsn$decayCounter(CallbackInfo ci) {
		int current = particleCounter.get();
		if (current > 0) {
			int div = AdaptivePerformance.isCpuPressure() || AdaptivePerformance.isRamPressure() ? 2 : 4;
			particleCounter.set(Math.max(0, current - Math.max(3, current / div)));
		}
	}

	@Unique
	private static boolean hsn$isBiomeAmbient(Object type) {
		if (type == null) return false;
		try {
			if (type == ParticleTypes.SPORE_BLOSSOM_AIR) return true;
			if (type == ParticleTypes.WARPED_SPORE) return true;
			if (type == ParticleTypes.CRIMSON_SPORE) return true;
			if (type == ParticleTypes.ASH) return true;
			if (type == ParticleTypes.WHITE_ASH) return true;
			if (type == ParticleTypes.UNDERWATER) return true;
		} catch (Throwable ignored) {}
		String s = type.toString().toLowerCase();
		return s.contains("spore") || s.contains("ash") || s.contains("drip")
				|| s.contains("falling_nectar") || s.contains("cherry")
				|| s.contains("mycelium") || s.contains("suspended");
	}

}
