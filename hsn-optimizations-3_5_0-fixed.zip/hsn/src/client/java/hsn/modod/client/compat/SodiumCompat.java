package hsn.modod.client.compat;

import hsn.modod.HSNOptimizations;
import net.fabricmc.loader.api.FabricLoader;

public final class SodiumCompat {

	private static boolean sodiumLoaded;
	private static boolean embeddiumLoaded;
	private static boolean mercurizerLoaded;

	private SodiumCompat() {}

	public static void init() {
		FabricLoader fl = FabricLoader.getInstance();
		sodiumLoaded = fl.isModLoaded("sodium");
		embeddiumLoaded = fl.isModLoaded("embeddium");
		mercurizerLoaded = fl.isModLoaded("mercurizer");

		if (mercurizerLoaded) {
			HSNOptimizations.LOGGER.info("Mercurizer detected — HSN tab hooks soft-enabled");
		} else if (sodiumLoaded) {
			HSNOptimizations.LOGGER.info("Sodium detected — HSN tab hooks soft-enabled");
		} else if (embeddiumLoaded) {
			HSNOptimizations.LOGGER.info("Embeddium detected — HSN tab hooks soft-enabled");
		} else {
			HSNOptimizations.LOGGER.info("No Sodium/Embeddium/Mercurizer — Mod Menu config only");
		}
	}

	public static boolean hasRendererMod() {
		return sodiumLoaded || embeddiumLoaded || mercurizerLoaded;
	}

	public static String getF3Line() {
		String version = "3.4.1";
		if (mercurizerLoaded) return "HSN-Optimizations " + version + " + Mercurizer";
		if (sodiumLoaded) return "HSN-Optimizations " + version + " + Sodium";
		if (embeddiumLoaded) return "HSN-Optimizations " + version + " + Embeddium";
		return "HSN-Optimizations " + version;
	}
}
