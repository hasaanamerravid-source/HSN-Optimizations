package hsn.modod.client.mixin;

import hsn.modod.config.HSNConfig;
import net.minecraft.world.level.biome.Biome;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.LinkedHashMap;
import java.util.Map;

@Mixin(Biome.class)
public class BiomeColorMixin {

	@Unique
	private static final Map<Long, Integer> HSN_COLOR_CACHE =
			java.util.Collections.synchronizedMap(new LinkedHashMap<>(512, 0.75f, true) {
				@Override
				protected boolean removeEldestEntry(Map.Entry<Long, Integer> e) {
					return size() > Math.max(64, HSNConfig.get().colorCacheSize);
				}
			});

	@Unique private static long hsn$hits;
	@Unique private static long hsn$misses;

	@Inject(method = "getFoliageColor", at = @At("HEAD"), cancellable = true, require = 0)
	private void hsn$foliageHead(CallbackInfoReturnable<Integer> cir) {
		if (!HSNConfig.get().colorCacheEnabled) return;
		long key = 2L << 48 | (System.identityHashCode(this) & 0xffffffffL);
		Integer v = HSN_COLOR_CACHE.get(key);
		if (v != null) { hsn$hits++; cir.setReturnValue(v); }
	}

	@Inject(method = "getFoliageColor", at = @At("RETURN"), require = 0)
	private void hsn$foliageStore(CallbackInfoReturnable<Integer> cir) {
		if (!HSNConfig.get().colorCacheEnabled) return;
		long key = 2L << 48 | (System.identityHashCode(this) & 0xffffffffL);
		if (!HSN_COLOR_CACHE.containsKey(key)) {
			hsn$misses++;
			Integer v = cir.getReturnValue();
			if (v != null) HSN_COLOR_CACHE.put(key, v);
		}
	}

	@Inject(method = "getWaterColor", at = @At("HEAD"), cancellable = true, require = 0)
	private void hsn$waterHead(CallbackInfoReturnable<Integer> cir) {
		if (!HSNConfig.get().colorCacheEnabled) return;
		long key = 3L << 48 | (System.identityHashCode(this) & 0xffffffffL);
		Integer v = HSN_COLOR_CACHE.get(key);
		if (v != null) { hsn$hits++; cir.setReturnValue(v); }
	}

	@Inject(method = "getWaterColor", at = @At("RETURN"), require = 0)
	private void hsn$waterStore(CallbackInfoReturnable<Integer> cir) {
		if (!HSNConfig.get().colorCacheEnabled) return;
		long key = 3L << 48 | (System.identityHashCode(this) & 0xffffffffL);
		if (!HSN_COLOR_CACHE.containsKey(key)) {
			hsn$misses++;
			Integer v = cir.getReturnValue();
			if (v != null) HSN_COLOR_CACHE.put(key, v);
		}
	}

	@Inject(method = "getGrassColor", at = @At("HEAD"), cancellable = true, require = 0)
	private void hsn$grassHead(double x, double z, CallbackInfoReturnable<Integer> cir) {
		if (!HSNConfig.get().colorCacheEnabled) return;
		long key = 1L << 48 | (System.identityHashCode(this) & 0xffffffffL)
				^ (((long) Math.floor(x / 32)) << 8) ^ (long) Math.floor(z / 32);
		Integer v = HSN_COLOR_CACHE.get(key);
		if (v != null) { hsn$hits++; cir.setReturnValue(v); }
	}

	@Inject(method = "getGrassColor", at = @At("RETURN"), require = 0)
	private void hsn$grassStore(double x, double z, CallbackInfoReturnable<Integer> cir) {
		if (!HSNConfig.get().colorCacheEnabled) return;
		long key = 1L << 48 | (System.identityHashCode(this) & 0xffffffffL)
				^ (((long) Math.floor(x / 32)) << 8) ^ (long) Math.floor(z / 32);
		if (!HSN_COLOR_CACHE.containsKey(key)) {
			hsn$misses++;
			Integer v = cir.getReturnValue();
			if (v != null) HSN_COLOR_CACHE.put(key, v);
		}
	}
}
