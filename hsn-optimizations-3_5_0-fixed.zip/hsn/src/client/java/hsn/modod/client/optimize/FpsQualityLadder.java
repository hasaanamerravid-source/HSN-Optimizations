package hsn.modod.client.optimize;

import hsn.modod.HSNOptimizations;
import hsn.modod.config.HSNConfig;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;

/**
 * When FPS is low, temporarily tighten particle/entity/shadow/BE distances.
 * When FPS recovers, ease back. Does not change render distance chunks.
 */
public final class FpsQualityLadder {

	private static int level = 0; // 0 = normal, 1 = mild, 2 = aggressive
	private static int stableTicks = 0;
	private static int logCd = 0;

	private FpsQualityLadder() {}

	public static void init() {
		ClientTickEvents.END_CLIENT_TICK.register(FpsQualityLadder::onTick);
	}

	private static void onTick(Minecraft client) {
		HSNConfig cfg = HSNConfig.get();
		if (!cfg.fpsQualityLadderEnabled || client.level == null) {
			level = 0;
			return;
		}
		int fps = 60;
		try {
			fps = client.getFps();
		} catch (Throwable t) {
			return;
		}

		int low = cfg.fpsLadderLowThreshold;
		int high = cfg.fpsLadderHighThreshold;

		if (fps < low) {
			stableTicks = 0;
			int target = fps < low / 2 ? 2 : 1;
			if (target > level) {
				level = target;
				log(fps);
			}
		} else if (fps > high) {
			stableTicks++;
			if (stableTicks > 40 && level > 0) {
				level--;
				stableTicks = 0;
				log(fps);
			}
		} else {
			stableTicks = 0;
		}
		if (logCd > 0) logCd--;
	}

	private static void log(int fps) {
		if (logCd > 0) return;
		logCd = 80;
		HSNOptimizations.LOGGER.info("FPS quality ladder level={} (fps={})", level, fps);
	}

	public static int level() {
		return level;
	}

	/** Multiplier for distances (lower = tighter). */
	public static double distanceFactor() {
		return switch (level) {
			case 1 -> 0.75;
			case 2 -> 0.55;
			default -> 1.0;
		};
	}

	public static double particleFactor() {
		return switch (level) {
			case 1 -> 0.7;
			case 2 -> 0.45;
			default -> 1.0;
		};
	}

	public static String f3() {
		return "HSN ladder L" + level + " x" + String.format("%.2f", distanceFactor());
	}
}
