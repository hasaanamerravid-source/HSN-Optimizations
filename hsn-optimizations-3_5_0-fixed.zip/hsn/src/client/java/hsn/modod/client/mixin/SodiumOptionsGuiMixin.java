package hsn.modod.client.mixin;

import hsn.modod.client.config.HSNConfigScreen;
import hsn.modod.config.HSNConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Soft-target many possible Sodium / Mercurizer / Embeddium options GUI class names.
 */
@Mixin(
		targets = {
				"net.caffeinemc.mods.sodium.client.gui.SodiumOptionsGUI",
				"me.jellysquid.mods.sodium.client.gui.SodiumOptionsGUI",
				"me.jellysquid.mods.sodium.client.gui.SodiumGameOptions",
				"net.caffeinemc.mods.sodium.client.gui.SodiumGameOptions",
				"org.embeddedt.embeddium.client.gui.SodiumOptionsGUI",
				"org.embeddedt.embeddium.gui.SodiumOptionsGUI",
				"me.flashyreese.mods.reeses_sodium_options.client.gui.SodiumVideoOptionsScreen"
		},
		priority = 1100
)
public abstract class SodiumOptionsGuiMixin {

	@Inject(method = {"init", "initWidgets", "rebuildGui", "clearAndInit"}, at = @At("RETURN"), require = 0)
	private void hsn$addTabButton(CallbackInfo ci) {
		if (!HSNConfig.get().sodiumTabEnabled) return;
		Object self = this;
		if (!(self instanceof Screen screen)) return;
		try {
			// Left side, above bottom bar — closer to sidebar UX
			int x = 6;
			int y = Math.max(6, screen.height - 48);
			Button btn = Button.builder(Component.literal("HSN Optimizations"), b -> {
				openScreen(Minecraft.getInstance(), HSNConfigScreen.create(screen));
			}).bounds(x, y, 150, 20).build();

			for (java.lang.reflect.Method m : Screen.class.getDeclaredMethods()) {
				if (m.getParameterCount() != 1) continue;
				String n = m.getName().toLowerCase();
				if (!(n.contains("addrenderable") || n.contains("addwidget") || n.contains("addbutton"))) continue;
				m.setAccessible(true);
				try {
					m.invoke(screen, btn);
					return;
				} catch (Throwable ignored) {}
			}
		} catch (Throwable ignored) {}
	}

	private static void openScreen(Minecraft mc, Screen next) {
		try {
			Object gui = mc.getClass().getField("gui").get(mc);
			gui.getClass().getMethod("setScreen", Screen.class).invoke(gui, next);
			return;
		} catch (Throwable ignored) {}
		try {
			mc.getClass().getMethod("setScreen", Screen.class).invoke(mc, next);
		} catch (Throwable ignored) {}
	}
}
