package hsn.modod.client.optimize;

import hsn.modod.HSNOptimizations;
import hsn.modod.config.HSNConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;

/**
 * Applies a few vanilla video options that help pre-2015 GPUs.
 * Uses reflection-style try/catch so renamed 26.2 enums do not break the build.
 */
public final class VanillaGraphicsHelper {

	private static boolean appliedThisSession = false;

	private VanillaGraphicsHelper() {}

	public static void applyOnce() {
		if (appliedThisSession) return;
		HSNConfig cfg = HSNConfig.get();
		if (!cfg.autoTuneVanillaGraphics) return;

		Minecraft client = Minecraft.getInstance();
		if (client == null || client.options == null) return;

		Options o = client.options;
		boolean any = false;

		// Clouds OFF
		try {
			Object cloudOpt = o.getClass().getMethod("cloudStatus").invoke(o);
			if (cloudOpt != null) {
				Class<?> enumCl = null;
				try {
					enumCl = Class.forName("net.minecraft.client.CloudStatus");
				} catch (ClassNotFoundException e1) {
					try {
						enumCl = Class.forName("net.minecraft.client.OptionInstance$Unit"); // unlikely
					} catch (ClassNotFoundException ignored) {}
				}
				if (enumCl != null && enumCl.isEnum()) {
					Object off = null;
					for (Object c : enumCl.getEnumConstants()) {
						if ("OFF".equals(c.toString()) || "false".equalsIgnoreCase(c.toString())) {
							off = c;
							break;
						}
					}
					if (off != null) {
						cloudOpt.getClass().getMethod("set", Object.class).invoke(cloudOpt, off);
						any = true;
					}
				}
			}
		} catch (Throwable t) {
			HSNOptimizations.LOGGER.debug("cloudStatus tune skipped: {}", t.toString());
		}

		// View bobbing OFF
		try {
			Object bob = o.getClass().getMethod("bobView").invoke(o);
			if (bob != null) {
				bob.getClass().getMethod("set", Object.class).invoke(bob, Boolean.FALSE);
				any = true;
			}
		} catch (Throwable t) {
			HSNOptimizations.LOGGER.debug("bobView tune skipped: {}", t.toString());
		}

		// Particles → lowest available enum constant (avoids hard dependency on ParticleStatus)
		try {
			Object particles = o.getClass().getMethod("particles").invoke(o);
			if (particles != null) {
				Object current = particles.getClass().getMethod("get").invoke(particles);
				if (current != null && current.getClass().isEnum()) {
					Object[] constants = current.getClass().getEnumConstants();
					// Prefer MINIMAL / MIN / DECREASED / lowest ordinal
					Object pick = constants[0];
					for (Object c : constants) {
						String n = c.toString();
						if (n.contains("MINIMAL") || n.contains("MIN") || n.equals("DECREASED")) {
							pick = c;
							break;
						}
					}
					particles.getClass().getMethod("set", Object.class).invoke(particles, pick);
					any = true;
				}
			}
		} catch (Throwable t) {
			HSNOptimizations.LOGGER.debug("particles tune skipped: {}", t.toString());
		}

		try {
			o.save();
		} catch (Throwable ignored) {}

		appliedThisSession = true;
		if (any) {
			HSNOptimizations.LOGGER.info("Auto-tuned vanilla graphics (best-effort for 26.2)");
		} else {
			HSNOptimizations.LOGGER.info(
					"Vanilla graphics auto-tune: no options applied (set clouds/particles manually if needed)");
		}
	}
}
