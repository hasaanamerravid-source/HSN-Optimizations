package hsn.modod.client.mixin;

import hsn.modod.client.optimize.FpsQualityLadder;
import hsn.modod.config.HSNConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BlockEntityRenderDispatcher.class)
public class BlockEntityRenderDispatcherMixin {

	@Inject(method = "render", at = @At("HEAD"), cancellable = true, require = 0)
	private void hsn$beDistance(BlockEntity blockEntity, float partialTick, com.mojang.blaze3d.vertex.PoseStack poseStack, Object bufferSource, CallbackInfo ci) {
		HSNConfig cfg = HSNConfig.get();
		if (!cfg.blockEntityCullingEnabled || blockEntity == null) return;
		Player player = Minecraft.getInstance().player;
		if (player == null) return;
		try {
			double dx = blockEntity.getBlockPos().getX() + 0.5 - player.getX();
			double dy = blockEntity.getBlockPos().getY() + 0.5 - player.getY();
			double dz = blockEntity.getBlockPos().getZ() + 0.5 - player.getZ();
			double limit = cfg.maxBlockEntityRenderDistance * FpsQualityLadder.distanceFactor();
			if (dx * dx + dy * dy + dz * dz > limit * limit) {
				ci.cancel();
			}
		} catch (Throwable ignored) {}
	}

	@Inject(method = "tryRender", at = @At("HEAD"), cancellable = true, require = 0)
	private void hsn$beTry(BlockEntity blockEntity, CallbackInfoReturnable<?> cir) {
		HSNConfig cfg = HSNConfig.get();
		if (!cfg.blockEntityCullingEnabled || blockEntity == null) return;
		Player player = Minecraft.getInstance().player;
		if (player == null) return;
		try {
			double dx = blockEntity.getBlockPos().getX() + 0.5 - player.getX();
			double dy = blockEntity.getBlockPos().getY() + 0.5 - player.getY();
			double dz = blockEntity.getBlockPos().getZ() + 0.5 - player.getZ();
			double limit = cfg.maxBlockEntityRenderDistance * FpsQualityLadder.distanceFactor();
			if (dx * dx + dy * dy + dz * dz > limit * limit) {
				cir.setReturnValue(null);
			}
		} catch (Throwable ignored) {}
	}
}
