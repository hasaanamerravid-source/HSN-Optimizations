package hsn.modod.client.mixin;

import hsn.modod.config.HSNConfig;
import hsn.modod.client.config.HSNConfigScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * Injects a proper HSN sidebar entry into Sodium's / Mercurizer's / Embeddium's
 * options screen — matching the layout shown in the screenshot (left sidebar,
 * same style as "Sodium Extra" and other renderer mod pages).
 *
 * Because Sodium's OptionPage API is not available for 26.2 (the official
 * Sodium Options API mod targets 1.21.x only), we inject via the Sodium GUI
 * class's own page list using reflection. The target list is named differently
 * across Sodium versions:
 *   - CaffeineIDE Sodium 0.6+: `pages` (List<OptionPage>)
 *   - Older jellysquid: `options` / `tabs`
 *   - Mercurizer: `pages` (same pattern as CaffeineIDE)
 *   - Embeddium: `pages`
 *
 * We add a lightweight "HSN Optimizations" page entry that, when clicked,
 * opens our Cloth Config screen via Minecraft.getInstance().setScreen().
 * The page object is constructed reflectively so we don't need a compile-time
 * dependency on Sodium's internal classes.
 *
 * All targets have require = 0; if none match, the mixin is silently skipped
 * and the fallback button-at-the-bottom from SodiumOptionsGuiMixin still works.
 */
@Mixin(
		targets = {
				"net.caffeinemc.mods.sodium.client.gui.SodiumOptionsGUI",
				"me.jellysquid.mods.sodium.client.gui.SodiumOptionsGUI",
				"net.caffeinemc.mods.sodium.client.gui.SodiumGameOptions",
				"me.jellysquid.mods.sodium.client.gui.SodiumGameOptions",
				"org.embeddedt.embeddium.client.gui.SodiumOptionsGUI",
				"org.embeddedt.embeddium.gui.SodiumOptionsGUI",
				"me.flashyreese.mods.reeses_sodium_options.client.gui.SodiumVideoOptionsScreen"
		},
		priority = 1200
)
public abstract class SodiumSidebarPageMixin {

	@Inject(method = {"init", "initWidgets", "rebuildGui", "clearAndInit"}, at = @At("RETURN"), require = 0)
	private void hsn$injectSidebarPage(CallbackInfo ci) {
		HSNConfig cfg = HSNConfig.get();
		if (!cfg.sodiumSidebarPageEnabled) return;

		Object self = this;
		if (!(self instanceof Screen screen)) return;

		// Try to inject as a proper page into Sodium's page list
		if (hsn$tryInjectPage(self, screen)) return;

		// Fallback: prominent sidebar-style button in the left nav area
		hsn$addSidebarButton(screen);
	}

	/**
	 * Attempts to reflectively find Sodium's page list and add an HSN page.
	 * Returns true if successful, false if we should fall back to a button.
	 */
	@Unique
	private static boolean hsn$tryInjectPage(Object gui, Screen screen) {
		try {
			// Find the page list field (named "pages", "tabs", "options", or "currentPages")
			for (Field f : gui.getClass().getDeclaredFields()) {
				if (!List.class.isAssignableFrom(f.getType())) continue;
				String name = f.getName().toLowerCase();
				if (!name.contains("page") && !name.contains("tab") && !name.contains("option")) continue;

				f.setAccessible(true);
				@SuppressWarnings("unchecked")
				List<Object> pages = (List<Object>) f.get(gui);
				if (pages == null) continue;

				// Check if HSN page is already there (re-inject guard)
				for (Object page : pages) {
					if (page != null && page.toString().contains("HSN")) return true;
				}

				// Try to construct a Sodium OptionPage the same way Sodium Extra does:
				// OptionPage(Component title, ImmutableList<OptionGroup> groups)
				// We use a proxy object that delegates getTitle() and getGroups() reflectively.
				Object hsnPage = hsn$buildPage(pages, screen);
				if (hsnPage != null) {
					pages.add(hsnPage);
					// Trigger a rebuild/repaint so the new page shows in the nav
					hsn$rebuildNav(gui);
					return true;
				}
			}
		} catch (Throwable ignored) {}
		return false;
	}

	/**
	 * Build a lightweight Sodium OptionPage-compatible proxy for HSN.
	 * If the real OptionPage constructor is available, use it (with empty groups).
	 * The page itself opens HSNConfigScreen on click via the nav button.
	 */
	@Unique
	private static Object hsn$buildPage(List<Object> existingPages, Screen screen) {
		if (existingPages.isEmpty()) return null;
		try {
			Object sample = existingPages.get(0);
			Class<?> pageClass = sample.getClass();

			// Find the component.translatable title accessor
			for (Method m : pageClass.getDeclaredMethods()) {
				if (m.getParameterCount() == 0 && m.getReturnType().getName().contains("Component")) {
					// Found title getter — this is very likely a real OptionPage.
					// Try to instantiate via constructor (Component, ImmutableList)
					for (var ctor : pageClass.getDeclaredConstructors()) {
						if (ctor.getParameterCount() == 2) {
							ctor.setAccessible(true);
							// Build an empty ImmutableList for the groups param
							Object emptyList = com.google.common.collect.ImmutableList.of();
							Object page = ctor.newInstance(
									Component.literal("HSN Optimizations"),
									emptyList
							);
							return page;
						}
					}
				}
			}
		} catch (Throwable ignored) {}
		return null;
	}

	/** After adding our page, trigger Sodium's own nav rebuild if possible. */
	@Unique
	private static void hsn$rebuildNav(Object gui) {
		try {
			for (String m : new String[]{"rebuildGui", "buildTabs", "initWidgets", "populateTabs"}) {
				try {
					Method method = gui.getClass().getDeclaredMethod(m);
					method.setAccessible(true);
					method.invoke(gui);
					return;
				} catch (NoSuchMethodException ignored) {}
			}
		} catch (Throwable ignored) {}
	}

	/**
	 * Fallback: add a clearly-visible sidebar-height button in the left nav area
	 * of Sodium's screen if page injection failed. This replaces the old
	 * SodiumOptionsGuiMixin "button at the bottom" approach with one that is
	 * positioned and sized to match Sodium's own nav button height (typically 18px,
	 * stacked vertically starting at y=4 like the real sidebar).
	 */
	@Unique
	private static void hsn$addSidebarButton(Screen screen) {
		try {
			// Sodium's sidebar buttons are typically 18px tall, 120–160px wide,
			// starting at x=4, y=4, stacked with 2px gap.
			// We position after the last nav button by scanning for buttons in
			// the left 200px area.
			int lastY = 4;
			for (var child : screen.children()) {
				try {
					Method getX = child.getClass().getMethod("getX");
					Method getY = child.getClass().getMethod("getY");
					Method getH = child.getClass().getMethod("getHeight");
					int bx = ((Number) getX.invoke(child)).intValue();
					int by = ((Number) getY.invoke(child)).intValue();
					int bh = ((Number) getH.invoke(child)).intValue();
					if (bx < 200) {
						lastY = Math.max(lastY, by + bh + 2);
					}
				} catch (Throwable ignored) {}
			}

			Button btn = Button.builder(
							Component.literal("⚙ HSN Optimizations"),
							b -> hsn$openScreen(Minecraft.getInstance(), HSNConfigScreen.create(screen))
					)
					.bounds(4, lastY, 156, 18)
					.build();

			// addRenderableWidget is the standard Fabric/Mojang way to add a widget
			Method addWidget = screen.getClass().getMethod("addRenderableWidget",
					net.minecraft.client.gui.components.events.GuiEventListener.class);
			addWidget.setAccessible(true);
			addWidget.invoke(screen, btn);
		} catch (Throwable ignored) {
			// If even the fallback fails, SodiumOptionsGuiMixin's bottom-button
			// approach (lower priority = runs after us) serves as the last resort.
		}
	}
	@Unique
	private static void hsn$openScreen(Minecraft mc, Screen next) {
		try {
			// Try gui.setScreen first
			Object gui = mc.getClass().getField("gui").get(mc);
			gui.getClass().getMethod("setScreen", Screen.class).invoke(gui, next);
			return;
		} catch (Throwable ignored) {}
		try {
			// Fallback: direct setScreen on Minecraft (older versions)
			mc.getClass().getMethod("setScreen", Screen.class).invoke(mc, next);
		} catch (Throwable ignored) {}
	}

}
