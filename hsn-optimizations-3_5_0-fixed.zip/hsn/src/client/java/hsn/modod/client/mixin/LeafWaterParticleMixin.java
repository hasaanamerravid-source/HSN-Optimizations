package hsn.modod.client.mixin;

import hsn.modod.client.optimize.AdaptivePerformance;
import hsn.modod.client.optimize.FpsQualityLadder;
import hsn.modod.config.HSNConfig;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleEngine;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Separate mixin for leaf decay / falling leaf particles and water ripple /
 * drip particles — two of the biggest overlooked particle sources on weak GPUs.
 *
 * Leaf particles appear constantly in oak/birch/jungle/spruce/azalea forests.
 * Water drip/splash/ripple particles appear near rivers, rain, and waterlogged
 * blocks and are generated at high frequency every tick.
 *
 * These are split from ParticleManagerMixin intentionally so both mixins stay
 * short and so disabling one doesn't affect the other.
 */
@Mixin(value = ParticleEngine.class, priority = 950)
public class LeafWaterParticleMixin {

	@Inject(
			method = "createParticle(Lnet/minecraft/core/particles/ParticleOptions;DDDDDD)Lnet/minecraft/client/particle/Particle;",
			at = @At("HEAD"),
			cancellable = true,
			require = 0
	)
	private void hsn$cullLeafAndWater(
			ParticleOptions options,
			double x, double y, double z,
			double xSpeed, double ySpeed, double zSpeed,
			CallbackInfoReturnable<Particle> cir
	) {
		HSNConfig cfg = HSNConfig.get();
		var type = options.getType();

		// --- Leaf particles ---
		// Falling leaves from oak, birch, jungle, spruce, cherry, azalea, mangrove, etc.
		// ParticleTypes doesn't have a universal LEAF type — they're registered per biome/block,
		// so we match by class name for forward-compat with new leaf types added in future versions.
		if (cfg.leafParticleCullingEnabled && hsn$isLeafParticle(type)) {
			double keepChance = cfg.leafParticleKeepChance;
			// Further reduce under CPU/RAM pressure or when FPS ladder is active
			if (AdaptivePerformance.isCpuPressure() || FpsQualityLadder.level() >= 1) {
				keepChance *= 0.4;
			}
			if (Math.random() > keepChance) {
				cir.setReturnValue(null);
				return;
			}
		}

		// --- Water ripple / drip particles ---
		if (cfg.waterRippleCullEnabled && hsn$isWaterRipple(type)) {
			double keepChance = cfg.waterRippleKeepChance;
			if (AdaptivePerformance.isCpuPressure() || FpsQualityLadder.level() >= 1) {
				keepChance *= 0.3;
			}
			if (Math.random() > keepChance) {
				cir.setReturnValue(null);
			}
		}
	}

	private static boolean hsn$isLeafParticle(Object type) {
		if (type == null) return false;
		try {
			// Cherry leaves: added in 1.20
			if (type == ParticleTypes.CHERRY_LEAVES) return true;
		} catch (Throwable ignored) {}
		// All other leaf particles are registered under custom ResourceLocation keys
		// like "minecraft:falling_leaf", "minecraft:oak_leaf" etc. and don't have
		// static fields on ParticleTypes. Match by toString for broad compatibility.
		String s = type.toString().toLowerCase();
		return s.contains("leaf") || s.contains("leaves")
				|| s.contains("petal") || s.contains("falling_nectar")
				|| s.contains("mycelium");
	}

	private static boolean hsn$isWaterRipple(Object type) {
		if (type == null) return false;
		try {
			if (type == ParticleTypes.DRIPPING_WATER) return true;
			if (type == ParticleTypes.FALLING_WATER) return true;
			if (type == ParticleTypes.DRIPPING_LAVA) return true;
			if (type == ParticleTypes.FALLING_LAVA) return true;
			if (type == ParticleTypes.UNDERWATER) return true;
		} catch (Throwable ignored) {}
		String s = type.toString().toLowerCase();
		return s.contains("drip") || s.contains("ripple") || s.contains("splash")
				|| s.contains("landing_water") || s.contains("bubble");
	}
}
