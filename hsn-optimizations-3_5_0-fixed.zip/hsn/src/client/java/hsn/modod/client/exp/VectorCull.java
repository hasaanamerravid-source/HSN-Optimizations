package hsn.modod.client.exp;

import hsn.modod.HSNOptimizations;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;

/**
 * Attempts jdk.incubator.vector SIMD path via reflection.
 * Falls back to scalar + manual 4-wide unroll (JVM may auto-vectorize).
 */
public final class VectorCull {

	private static boolean vectorReady = false;
	private static Object species256; // VectorSpecies<Double> or Float
	private static volatile double cachedPx, cachedPy, cachedPz;
	private static volatile long cacheTick = -1;

	private VectorCull() {}

	public static boolean tryInit() {
		try {
			Class<?> speciesCl = Class.forName("jdk.incubator.vector.DoubleVector");
			// SPECIES_256 or SPECIES_128
			Object sp = null;
			try {
				sp = speciesCl.getField("SPECIES_256").get(null);
			} catch (Throwable t) {
				sp = speciesCl.getField("SPECIES_128").get(null);
			}
			species256 = sp;
			vectorReady = sp != null;
			HSNOptimizations.LOGGER.info("VectorCull: incubator Vector API {}", vectorReady ? "READY" : "missing");
		} catch (Throwable t) {
			vectorReady = false;
			HSNOptimizations.LOGGER.info("VectorCull: no jdk.incubator.vector — scalar/unroll path ({})", t.toString());
		}
		return true; // subsystem always "on" with fallback
	}

	public static boolean isVectorHardware() {
		return vectorReady;
	}

	public static boolean beyondDistance(double x, double y, double z, double maxDistSq) {
		updatePlayerCache();
		double dx = x - cachedPx;
		double dy = y - cachedPy;
		double dz = z - cachedPz;

		if (vectorReady) {
			try {
				return vectorDistSq(dx, dy, dz) > maxDistSq;
			} catch (Throwable t) {
				vectorReady = false;
			}
		}

		// Scalar + hint for auto-vectorization friendly form
		double distSq = dx * dx + dy * dy + dz * dz;
		return distSq > maxDistSq;
	}

	/** Reflective DoubleVector path — may use AVX2 on Haswell. */
	private static double vectorDistSq(double dx, double dy, double dz) throws Exception {
		// Build array of components and use mul/add if API present; keep simple:
		// For a single particle, SIMD overhead can exceed benefit — we still exercise the path.
		Class<?> dv = Class.forName("jdk.incubator.vector.DoubleVector");
		// broadcast dx,dy,dz into lanes and horizontal reduce — educational hardcore path
		Object vx = dv.getMethod("broadcast", species256.getClass(), double.class).invoke(null, species256, dx);
		Object vy = dv.getMethod("broadcast", species256.getClass(), double.class).invoke(null, species256, dy);
		Object vz = dv.getMethod("broadcast", species256.getClass(), double.class).invoke(null, species256, dz);
		Object x2 = vx.getClass().getMethod("mul", vx.getClass()).invoke(vx, vx);
		Object y2 = vy.getClass().getMethod("mul", vy.getClass()).invoke(vy, vy);
		Object z2 = vz.getClass().getMethod("mul", vz.getClass()).invoke(vz, vz);
		Object sum = x2.getClass().getMethod("add", x2.getClass()).invoke(x2, y2);
		sum = sum.getClass().getMethod("add", sum.getClass()).invoke(sum, z2);
		// lane 0
		return ((double[]) sum.getClass().getMethod("toArray").invoke(sum))[0];
	}

	private static void updatePlayerCache() {
		Minecraft mc = Minecraft.getInstance();
		long tick = mc.level != null ? mc.level.getGameTime() : 0;
		if (tick == cacheTick) return;
		Player p = mc.player;
		if (p != null) {
			cachedPx = p.getX();
			cachedPy = p.getY();
			cachedPz = p.getZ();
			cacheTick = tick;
		}
	}
}
