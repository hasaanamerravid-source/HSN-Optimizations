package hsn.modod.client.mixin;

import hsn.modod.config.HSNConfig;
import hsn.modod.client.optimize.FastMath;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Skips the client-side "lerpTo" / "lerpMotion" position interpolation update
 * for entities that are very far from the player. These calls happen every packet
 * from the server (typically 20 Hz per entity) and do float/trig work even for
 * entities the player can't see anyway. Skipping them for entities beyond the
 * configured threshold is safe: the entity will teleport slightly when it comes
 * back into range, but it was invisible during the skip window anyway.
 *
 * DEFAULT OFF — conservative feature. Enable via config.
 * Never applies to the local player or any Player entity.
 */
@Mixin(Entity.class)
public class EntityInterpolationMixin {

	@Inject(
			method = {
					"lerpTo",
					"absMoveTo",
					"lerpMotion"
			},
			at = @At("HEAD"),
			cancellable = true,
			require = 0
	)
	private void hsn$skipFarInterp(
			double x, double y, double z,
			CallbackInfo ci
	) {
		HSNConfig cfg = HSNConfig.get();
		if (!cfg.entityInterpolationSkipEnabled) return;

		Entity self = (Entity) (Object) this;
		if (self instanceof Player) return; // never skip players

		Minecraft client = Minecraft.getInstance();
		if (client.player == null) return;
		if (client.level == null || !client.level.isClientSide()) return;

		double dx = self.getX() - client.player.getX();
		double dy = self.getY() - client.player.getY();
		double dz = self.getZ() - client.player.getZ();
		if (FastMath.distSq(dx, dy, dz) > cfg.entityInterpolationSkipDistanceSq()) {
			ci.cancel();
		}
	}
}
