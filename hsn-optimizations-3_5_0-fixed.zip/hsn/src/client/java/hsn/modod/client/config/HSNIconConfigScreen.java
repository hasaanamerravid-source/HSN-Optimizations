package hsn.modod.client.config;

import net.minecraft.client.gui.screens.Screen;

/** Rolled back — use Cloth Config via HSNConfigScreen.create(). */
public final class HSNIconConfigScreen {
	private HSNIconConfigScreen() {}
	public static Screen create(Screen parent) {
		return HSNConfigScreen.create(parent);
	}
}
