package hsn.modod.client.optimize;

import hsn.modod.config.HSNConfig;

/**
 * Optional fast approximations for distance / angle work (Sodium-style "fast math").
 * Not as accurate as StrictMath; fine for culling thresholds.
 */
public final class FastMath {

	private static final int SIN_BITS = 12;
	private static final int SIN_MASK = ~(-1 << SIN_BITS);
	private static final int SIN_COUNT = SIN_MASK + 1;
	private static final float[] SIN = new float[SIN_COUNT];
	private static final float RAD_TO_INDEX = SIN_COUNT / (float) (Math.PI * 2.0);

	static {
		for (int i = 0; i < SIN_COUNT; i++) {
			SIN[i] = (float) Math.sin((i + 0.5f) / SIN_COUNT * Math.PI * 2.0);
		}
	}

	private FastMath() {}

	public static boolean enabled() {
		return HSNConfig.get().fastMathEnabled;
	}

	public static float sin(float rad) {
		if (!enabled()) return (float) Math.sin(rad);
		return SIN[Math.round(rad * RAD_TO_INDEX) & SIN_MASK];
	}

	public static float cos(float rad) {
		if (!enabled()) return (float) Math.cos(rad);
		return sin(rad + (float) (Math.PI * 0.5));
	}

	/** Squared distance without hypot; optional fast path is just plain mul-add. */
	public static double distSq(double dx, double dy, double dz) {
		return dx * dx + dy * dy + dz * dz;
	}

	public static boolean beyond(double dx, double dy, double dz, double limitSq) {
		return distSq(dx, dy, dz) > limitSq;
	}
}
