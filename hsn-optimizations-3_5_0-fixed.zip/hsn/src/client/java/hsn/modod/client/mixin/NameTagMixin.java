package hsn.modod.client.mixin;

import hsn.modod.client.optimize.FastMath;
import hsn.modod.client.optimize.FpsQualityLadder;
import hsn.modod.config.HSNConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityRenderer.class)
public class NameTagMixin {

	@Inject(
			method = {
					"renderNameTag",
					"renderLabelIfPresent",
					"renderName"
			},
			at = @At("HEAD"),
			cancellable = true,
			require = 0
	)
	private void hsn$nameTagCull(Entity entity, CallbackInfo ci) {
		HSNConfig cfg = HSNConfig.get();
		if (!cfg.nameTagCullEnabled || entity == null) return;
		Player player = Minecraft.getInstance().player;
		if (player == null || entity == player) return;
		double dx = entity.getX() - player.getX();
		double dy = entity.getY() - player.getY();
		double dz = entity.getZ() - player.getZ();
		double limit = cfg.maxNameTagDistance * FpsQualityLadder.distanceFactor();
		if (FastMath.distSq(dx, dy, dz) > limit * limit) {
			ci.cancel();
		}
	}
}
