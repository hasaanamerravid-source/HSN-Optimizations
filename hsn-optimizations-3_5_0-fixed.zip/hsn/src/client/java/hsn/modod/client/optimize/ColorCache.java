package hsn.modod.client.optimize;

import hsn.modod.config.HSNConfig;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

/** LRU cache for biome/sky/grass/water colors — cuts redundant recalculation. */
public final class ColorCache {

	private static final AtomicLong hits = new AtomicLong();
	private static final AtomicLong misses = new AtomicLong();
	private static Map<Long, Integer> cache = newCache(512);

	private ColorCache() {}

	private static Map<Long, Integer> newCache(int size) {
		final int cap = Math.max(64, size);
		return java.util.Collections.synchronizedMap(new LinkedHashMap<>(cap, 0.75f, true) {
			@Override
			protected boolean removeEldestEntry(Map.Entry<Long, Integer> e) {
				return size() > cap;
			}
		});
	}

	public static void resize(int size) {
		cache = newCache(size);
		hits.set(0);
		misses.set(0);
	}

	public static void clear() {
		cache.clear();
	}

	public static int getOrCompute(long key, IntSupplier compute) {
		if (!HSNConfig.get().colorCacheEnabled) {
			return compute.getAsInt();
		}
		Integer v = cache.get(key);
		if (v != null) {
			hits.incrementAndGet();
			return v;
		}
		misses.incrementAndGet();
		int c = compute.getAsInt();
		cache.put(key, c);
		return c;
	}

	public static String stats() {
		long h = hits.get(), m = misses.get();
		long t = h + m;
		int pct = t == 0 ? 0 : (int) (h * 100 / t);
		return "colorCache " + pct + "% hits (" + cache.size() + ")";
	}

	@FunctionalInterface
	public interface IntSupplier {
		int getAsInt();
	}
}
