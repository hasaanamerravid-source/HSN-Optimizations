package hsn.modod.client.mixin;

import hsn.modod.client.optimize.AdaptivePerformance;
import hsn.modod.client.optimize.FpsQualityLadder;
import hsn.modod.config.HSNConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Client networking relief: under load, randomly drop incoming particle packets
 * so the network + particle engine do less work. Does not affect block/entity sync.
 */
@Mixin(targets = {
		"net.minecraft.client.multiplayer.ClientPacketListener",
		"net.minecraft.client.network.ClientPlayNetworkHandler"
}, priority = 900)
public class ClientPacketListenerMixin {

	@Inject(
			method = {
					"handleParticleEvent",
					"onParticle",
					"handleParticles",
					"m_7255_"
			},
			at = @At("HEAD"),
			cancellable = true,
			require = 0
	)
	private void hsn$netParticle(CallbackInfo ci) {
		HSNConfig cfg = HSNConfig.get();
		if (!cfg.networkParticleCullEnabled) return;
		if (AdaptivePerformance.isCpuPressure() || AdaptivePerformance.isRamPressure() || FpsQualityLadder.level() > 0) {
			if (Math.random() < 0.45) {
				ci.cancel();
			}
		} else if (FpsQualityLadder.level() == 0 && Math.random() < 0.05 && cfg.maxParticles < 500) {
			// light random drop even when healthy on ULTRA_LOW
			ci.cancel();
		}
	}
}
