package hsn.modod.client;

import hsn.modod.HSNOptimizations;
import hsn.modod.client.compat.SodiumCompat;
import hsn.modod.client.compat.StackHub;
import hsn.modod.client.exp.HardcoreExp;
import hsn.modod.client.optimize.AdaptivePerformance;
import hsn.modod.client.optimize.FpsOverlay;
import hsn.modod.client.optimize.FpsQualityLadder;
import hsn.modod.client.optimize.IdleMemoryTrim;
import hsn.modod.client.optimize.InputLatencyHelper;
import hsn.modod.client.optimize.JvmTuneHelper;
import hsn.modod.client.optimize.PreferOpenGLHelper;
import hsn.modod.client.optimize.SkyFogHelper;
import hsn.modod.client.optimize.SmoothLightingHelper;
import hsn.modod.client.optimize.VanillaGraphicsHelper;
import hsn.modod.config.HSNConfig;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public class HSNOptimizationsClient implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		HSNConfig cfg = HSNConfig.get();

		SodiumCompat.init();
		IdleMemoryTrim.init();
		AdaptivePerformance.init();
		FpsQualityLadder.init();
		HardcoreExp.init();
		JvmTuneHelper.init();
		PreferOpenGLHelper.applyFromConfig();
		SmoothLightingHelper.applyFromConfig();

		HSNKeybinds.register();
		FpsOverlay.register();

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (client.level != null) {
				VanillaGraphicsHelper.applyOnce();
				SkyFogHelper.tick(client);
				InputLatencyHelper.apply(client);
				JvmTuneHelper.softGcIfEnabled();
			}
		});

		HSNOptimizations.LOGGER.info("HSN-Optimizations 3.4.1 ready — preset {}", cfg.lastAppliedPreset);
		HSNOptimizations.LOGGER.info("{}", StackHub.summaryOneLine());
		HSNOptimizations.LOGGER.info(
				"Hotkeys F8=ULTRA_LOW F9=SAFE F7=FPS overlay | overlay={} input={}",
				cfg.fpsOverlayEnabled, cfg.inputLatencyEnabled);
	}
}
