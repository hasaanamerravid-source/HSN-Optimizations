package hsn.modod.client.optimize;

import hsn.modod.HSNOptimizations;
import hsn.modod.config.HSNConfig;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

/**
 * Best-effort input latency: raw mouse via GLFW handle reflection (26.2-safe).
 */
public final class InputLatencyHelper {

	private static boolean applied;
	private static boolean rawTried;

	private InputLatencyHelper() {}

	public static void apply(Minecraft client) {
		HSNConfig cfg = HSNConfig.get();
		if (!cfg.inputLatencyEnabled || client == null) return;

		if (cfg.rawMouseEnabled && !rawTried) {
			rawTried = true;
			tryEnableRawMouse(client);
		}

		if (cfg.reduceMouseSmoothing && !applied) {
			try {
				Object options = client.options;
				for (String name : new String[]{"rawMouseInput", "discreteMouseScroll"}) {
					try {
						Object opt = options.getClass().getField(name).get(options);
						if (opt != null) {
							try {
								opt.getClass().getMethod("set", boolean.class).invoke(opt, true);
							} catch (Throwable t2) {
								opt.getClass().getMethod("setValue", Object.class).invoke(opt, Boolean.TRUE);
							}
						}
					} catch (Throwable ignored) {}
				}
			} catch (Throwable ignored) {}
			applied = true;
			HSNOptimizations.LOGGER.info("HSN input latency: options hints applied");
		}
	}

	private static void tryEnableRawMouse(Minecraft client) {
		try {
			Object win = client.getWindow();
			long handle = resolveGlfwHandle(win);
			if (handle != 0L) {
				GLFW.glfwSetInputMode(handle, GLFW.GLFW_RAW_MOUSE_MOTION, GLFW.GLFW_TRUE);
				HSNOptimizations.LOGGER.info("HSN input latency: GLFW raw mouse enabled");
			} else {
				HSNOptimizations.LOGGER.info("HSN input latency: no GLFW handle found (skip raw mouse)");
			}
		} catch (Throwable t) {
			HSNOptimizations.LOGGER.debug("Raw mouse failed: {}", t.toString());
		}
	}

	private static long resolveGlfwHandle(Object win) {
		if (win == null) return 0L;
		for (String name : new String[]{"getHandle", "getWindow", "handle", "getGLFWWindowHandle", "getWindowHandle"}) {
			try {
				Object r = win.getClass().getMethod(name).invoke(win);
				if (r instanceof Long l) return l;
				if (r instanceof Number n) return n.longValue();
			} catch (Throwable ignored) {}
		}
		for (String fname : new String[]{"handle", "window", "glfwWindow"}) {
			try {
				var f = win.getClass().getDeclaredField(fname);
				f.setAccessible(true);
				Object r = f.get(win);
				if (r instanceof Long l) return l;
				if (r instanceof Number n) return n.longValue();
			} catch (Throwable ignored) {}
		}
		return 0L;
	}
}
