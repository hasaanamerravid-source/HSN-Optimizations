package hsn.modod.client.config;

import net.minecraft.client.gui.screens.Screen;

/** Rolled back — Cloth Config is the config UI. */
public final class HSNHomeScreen {
	public enum Section {
		ABOUT, PRESETS, PARTICLES, ENTITIES, MEMORY, VRD
	}
	private HSNHomeScreen() {}
	public static Screen create(Screen parent) {
		return HSNConfigScreen.create(parent);
	}
}
