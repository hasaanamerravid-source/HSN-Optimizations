package hsn.modod.client.config;

import hsn.modod.client.optimize.JvmTuneHelper;
import hsn.modod.client.compat.StackHub;
import hsn.modod.client.optimize.SmoothLightingHelper;
import hsn.modod.config.HSNConfig;
import hsn.modod.config.HSNConfig.Preset;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import hsn.modod.client.config.HSNHomeScreen.Section;

/**
 * Clean Cloth Config layout — left tabs grouped for weak-PC users.
 */
public final class HSNConfigScreen {

	private HSNConfigScreen() {}

	public static Screen create(Screen parent) {
		return buildCloth(parent);
	}

	public static Screen createFull(Screen parent) {
		return buildCloth(parent);
	}

	public static Screen createForSection(Screen parent, Section section) {
		return buildCloth(parent);
	}

	private static Screen buildCloth(Screen parent) {
		HSNConfig cfg = HSNConfig.get();
		ConfigBuilder builder = ConfigBuilder.create()
				.setParentScreen(parent)
				.setTitle(Component.literal("HSN Optimizations"))
				.setSavingRunnable(() -> {
					cfg.onSaved();
					SmoothLightingHelper.applyFromConfig();
				});

		ConfigEntryBuilder e = builder.entryBuilder();

		// --- 1 About ---
		ConfigCategory about = builder.getOrCreateCategory(Component.literal("1 · About / Hub"));
		about.addEntry(e.startTextDescription(Component.literal(
				"HSN-Optimizations 3.4.1 — weak / pre-2015 GPUs (HD 4000/4600-class).")).build());
		about.addEntry(e.startTextDescription(Component.literal(
				StackHub.summaryOneLine())).build());
		for (String line : StackHub.statusLines()) {
			about.addEntry(e.startTextDescription(Component.literal(line)).build());
		}
		for (String tip : StackHub.weakPcTips()) {
			about.addEntry(e.startTextDescription(Component.literal(tip)).build());
		}
		about.addEntry(e.startTextDescription(Component.literal(
				JvmTuneHelper.summaryLine())).build());
		about.addEntry(e.startTextDescription(Component.literal(
				"Hotkeys: F8 ULTRA_LOW · F9 SAFE MODE · F7 FPS overlay toggle")).build());
		about.addEntry(e.startTextDescription(Component.literal(
				"SMP/PvP: raise entity distance or disable entity culling.")).build());

		// --- 2 Presets ---
		ConfigCategory presets = builder.getOrCreateCategory(Component.literal("2 · Presets"));
		presets.addEntry(e.startEnumSelector(Component.literal("Preset"), Preset.class, cfg.lastAppliedPreset)
				.setDefaultValue(Preset.ULTRA_LOW)
				.setTooltip(Component.literal("ULTRA_LOW = max FPS on weak hardware."))
				.setSaveConsumer(v -> cfg.lastAppliedPreset = v)
				.build());
		presets.addEntry(e.startBooleanToggle(Component.literal("Apply selected preset on Save"), cfg.applySelectedPreset)
				.setDefaultValue(false)
				.setTooltip(Component.literal("ON = overwrites toggles with preset values when you save."))
				.setSaveConsumer(v -> cfg.applySelectedPreset = v)
				.build());
		presets.addEntry(e.startBooleanToggle(Component.literal("SAFE MODE (one-click mild)"), cfg.applySafeMode)
				.setDefaultValue(false)
				.setSaveConsumer(v -> cfg.applySafeMode = v)
				.build());

		// --- 3 Particles ---
		ConfigCategory particles = builder.getOrCreateCategory(Component.literal("3 · Particles"));
		particles.addEntry(e.startBooleanToggle(Component.literal("Particle culling"), cfg.particleCullingEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.particleCullingEnabled = v).build());
		particles.addEntry(e.startIntField(Component.literal("Max particles"), cfg.maxParticles)
				.setDefaultValue(350).setMin(40).setMax(5000).setSaveConsumer(v -> cfg.maxParticles = v).build());
		particles.addEntry(e.startDoubleField(Component.literal("Max particle distance"), cfg.maxParticleDistance)
				.setDefaultValue(14.0).setMin(4.0).setMax(128.0).setSaveConsumer(v -> cfg.maxParticleDistance = v).build());
		particles.addEntry(e.startDoubleField(Component.literal("Rain keep chance"), cfg.rainKeepChance)
				.setDefaultValue(0.06).setMin(0.0).setMax(1.0).setSaveConsumer(v -> cfg.rainKeepChance = v).build());
		particles.addEntry(e.startDoubleField(Component.literal("Smoke keep chance"), cfg.smokeKeepChance)
				.setDefaultValue(0.10).setMin(0.0).setMax(1.0).setSaveConsumer(v -> cfg.smokeKeepChance = v).build());
		particles.addEntry(e.startDoubleField(Component.literal("Heavy particle keep chance"), cfg.heavyParticleKeepChance)
				.setDefaultValue(0.08).setMin(0.0).setMax(1.0).setSaveConsumer(v -> cfg.heavyParticleKeepChance = v).build());
		particles.addEntry(e.startBooleanToggle(Component.literal("Biome particle extra cull"), cfg.biomeParticleExtraCullEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.biomeParticleExtraCullEnabled = v).build());
		particles.addEntry(e.startBooleanToggle(Component.literal("Light particle cull"), cfg.lightParticleCullingEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.lightParticleCullingEnabled = v).build());

		// --- 4 Entities ---
		ConfigCategory entities = builder.getOrCreateCategory(Component.literal("4 · Entities"));
		entities.addEntry(e.startBooleanToggle(Component.literal("Entity distance cull"), cfg.entityCullingEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.entityCullingEnabled = v).build());
		entities.addEntry(e.startDoubleField(Component.literal("Max entity distance"), cfg.maxEntityRenderDistance)
				.setDefaultValue(28.0).setMin(8.0).setMax(256.0).setSaveConsumer(v -> cfg.maxEntityRenderDistance = v).build());
		entities.addEntry(e.startDoubleField(Component.literal("Max item distance"), cfg.maxItemEntityRenderDistance)
				.setDefaultValue(18.0).setMin(4.0).setMax(128.0).setSaveConsumer(v -> cfg.maxItemEntityRenderDistance = v).build());
		entities.addEntry(e.startDoubleField(Component.literal("Max XP orb distance"), cfg.maxXpOrbRenderDistance)
				.setDefaultValue(14.0).setMin(4.0).setMax(128.0).setSaveConsumer(v -> cfg.maxXpOrbRenderDistance = v).build());
		entities.addEntry(e.startBooleanToggle(Component.literal("Shadow distance cull"), cfg.shadowCullingEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.shadowCullingEnabled = v).build());
		entities.addEntry(e.startDoubleField(Component.literal("Max shadow distance"), cfg.maxShadowDistance)
				.setDefaultValue(10.0).setMin(0.0).setMax(128.0).setSaveConsumer(v -> cfg.maxShadowDistance = v).build());
		entities.addEntry(e.startBooleanToggle(Component.literal("Name tag cull"), cfg.nameTagCullEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.nameTagCullEnabled = v).build());
		entities.addEntry(e.startBooleanToggle(Component.literal("Distant animation skip"), cfg.distantAnimationSkipEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.distantAnimationSkipEnabled = v).build());
		entities.addEntry(e.startBooleanToggle(Component.literal("Block-entity distance cull"), cfg.blockEntityCullingEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.blockEntityCullingEnabled = v).build());

		// --- 5 MAX ---
		ConfigCategory max = builder.getOrCreateCategory(Component.literal("5 · MAX / Visual"));
		max.addEntry(e.startBooleanToggle(Component.literal("FPS quality ladder"), cfg.fpsQualityLadderEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.fpsQualityLadderEnabled = v).build());
		max.addEntry(e.startIntSlider(Component.literal("Ladder low FPS"), cfg.fpsLadderLowThreshold, 15, 60)
				.setDefaultValue(35).setSaveConsumer(v -> cfg.fpsLadderLowThreshold = v).build());
		max.addEntry(e.startIntSlider(Component.literal("Ladder recover FPS"), cfg.fpsLadderHighThreshold, 30, 120)
				.setDefaultValue(55).setSaveConsumer(v -> cfg.fpsLadderHighThreshold = v).build());
		max.addEntry(e.startBooleanToggle(Component.literal("Color cache"), cfg.colorCacheEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.colorCacheEnabled = v).build());
		max.addEntry(e.startBooleanToggle(Component.literal("Fog follows ladder"), cfg.fogLadderEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.fogLadderEnabled = v).build());
		max.addEntry(e.startBooleanToggle(Component.literal("Clouds off under load"), cfg.skyCloudLadderEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.skyCloudLadderEnabled = v).build());
		max.addEntry(e.startBooleanToggle(Component.literal("Reduce animated textures under load"), cfg.reduceAnimatedTextures)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.reduceAnimatedTextures = v).build());
		max.addEntry(e.startBooleanToggle(Component.literal("Disable smooth lighting (AO)"), cfg.disableSmoothLighting)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.disableSmoothLighting = v).build());
		max.addEntry(e.startBooleanToggle(Component.literal("Fast math"), cfg.fastMathEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.fastMathEnabled = v).build());

		// --- 6 Memory / JVM ---
		ConfigCategory mem = builder.getOrCreateCategory(Component.literal("6 · Memory / JVM"));
		mem.addEntry(e.startTextDescription(Component.literal(
				"Heap size is set by the LAUNCHER. This mod only recommends flags and can soft-GC.")).build());
		mem.addEntry(e.startTextDescription(Component.literal(JvmTuneHelper.summaryLine())).build());
		mem.addEntry(e.startBooleanToggle(Component.literal("Log JVM recommendations at start"), cfg.jvmTuneHintsEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.jvmTuneHintsEnabled = v).build());
		mem.addEntry(e.startIntSlider(Component.literal("Preferred Xmx (MB) for hints"), cfg.recommendedXmxMb, 512, 6144)
				.setDefaultValue(2048)
				.setTooltip(Component.literal("Capped by detected host RAM (8GB PC → usually ≤3072)."))
				.setSaveConsumer(v -> cfg.recommendedXmxMb = v).build());
		mem.addEntry(e.startBooleanToggle(Component.literal("Soft GC on idle + RAM pressure"), cfg.softGcOnIdlePressure)
				.setDefaultValue(false)
				.setTooltip(Component.literal("OFF recommended. Can cause hitches if spammed."))
				.setSaveConsumer(v -> cfg.softGcOnIdlePressure = v).build());
		mem.addEntry(e.startBooleanToggle(Component.literal("Adaptive RAM throttle"), cfg.adaptiveRamEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.adaptiveRamEnabled = v).build());
		mem.addEntry(e.startBooleanToggle(Component.literal("Adaptive CPU throttle"), cfg.adaptiveCpuEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.adaptiveCpuEnabled = v).build());
		mem.addEntry(e.startBooleanToggle(Component.literal("Idle memory trim"), cfg.idleMemoryTrimEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.idleMemoryTrimEnabled = v).build());

		// --- 7 Input ---
		ConfigCategory input = builder.getOrCreateCategory(Component.literal("7 · Input latency"));
		input.addEntry(e.startTextDescription(Component.literal(
				"Best-effort. Also turn VSync OFF in Sodium and use a high max FPS for lowest lag.")).build());
		input.addEntry(e.startBooleanToggle(Component.literal("Input latency mode"), cfg.inputLatencyEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.inputLatencyEnabled = v).build());
		input.addEntry(e.startBooleanToggle(Component.literal("Raw mouse (GLFW)"), cfg.rawMouseEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.rawMouseEnabled = v).build());
		input.addEntry(e.startBooleanToggle(Component.literal("Reduce mouse smoothing"), cfg.reduceMouseSmoothing)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.reduceMouseSmoothing = v).build());
		input.addEntry(e.startBooleanToggle(Component.literal("Low-latency keyboard hints"), cfg.lowLatencyKeyboard)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.lowLatencyKeyboard = v).build());

		// --- 8 Net ---
		ConfigCategory net = builder.getOrCreateCategory(Component.literal("8 · Network / Sound"));
		net.addEntry(e.startBooleanToggle(Component.literal("Network particle cull under load"), cfg.networkParticleCullEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.networkParticleCullEnabled = v).build());
		net.addEntry(e.startBooleanToggle(Component.literal("Sound distance cull"), cfg.soundDistanceCullingEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.soundDistanceCullingEnabled = v).build());
		net.addEntry(e.startBooleanToggle(Component.literal("Weather sound reduction"), cfg.weatherSoundReductionEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.weatherSoundReductionEnabled = v).build());
		net.addEntry(e.startBooleanToggle(Component.literal("Toast limit"), cfg.toastLimitEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.toastLimitEnabled = v).build());

		// --- 9 Extra ---
		ConfigCategory extra = builder.getOrCreateCategory(Component.literal("9 · Extra"));
		extra.addEntry(e.startBooleanToggle(Component.literal("Prefer higher OpenGL"), cfg.preferOpenGl)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.preferOpenGl = v).build());
		extra.addEntry(e.startBooleanToggle(Component.literal("Auto-tune vanilla graphics"), cfg.autoTuneVanillaGraphics)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.autoTuneVanillaGraphics = v).build());
		
		extra.addEntry(e.startBooleanToggle(Component.literal("FPS overlay badge"), cfg.fpsOverlayEnabled)
				.setDefaultValue(false)
				.setTooltip(Component.literal("Also toggle with F7."))
				.setSaveConsumer(v -> cfg.fpsOverlayEnabled = v).build());
		extra.addEntry(e.startBooleanToggle(Component.literal("Overlay shows stack tags"), cfg.fpsOverlayShowStack)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.fpsOverlayShowStack = v).build());
		extra.addEntry(e.startIntField(Component.literal("Overlay X"), cfg.fpsOverlayX)
				.setDefaultValue(4).setMin(0).setMax(2000).setSaveConsumer(v -> cfg.fpsOverlayX = v).build());
		extra.addEntry(e.startIntField(Component.literal("Overlay Y"), cfg.fpsOverlayY)
				.setDefaultValue(4).setMin(0).setMax(2000).setSaveConsumer(v -> cfg.fpsOverlayY = v).build());
	extra.addEntry(e.startBooleanToggle(Component.literal("Show adaptive status on F3"), cfg.f3ShowAdaptiveStatus)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.f3ShowAdaptiveStatus = v).build());
		extra.addEntry(e.startBooleanToggle(Component.literal("Sodium GUI HSN button (soft)"), cfg.sodiumTabEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.sodiumTabEnabled = v).build());

		// --- 10 · Rendering Extras ---
		ConfigCategory rendering = builder.getOrCreateCategory(Component.literal("10 · Rendering Extras"));
		rendering.addEntry(e.startTextDescription(Component.literal(
				"Leaf/water particles, explosion caps, entity interpolation, cloud reduction, chunk-load culling.")).build());

		rendering.addEntry(e.startBooleanToggle(Component.literal("Cull leaf particles"), cfg.leafParticleCullingEnabled)
				.setDefaultValue(true)
				.setTooltip(Component.literal("Reduces falling leaf/petal particles. Big FPS gain in forests."))
				.setSaveConsumer(v -> cfg.leafParticleCullingEnabled = v).build());
		rendering.addEntry(e.startDoubleField(Component.literal("Leaf keep chance"), cfg.leafParticleKeepChance)
				.setDefaultValue(0.08).setMin(0.0).setMax(1.0)
				.setSaveConsumer(v -> cfg.leafParticleKeepChance = v).build());

		rendering.addEntry(e.startBooleanToggle(Component.literal("Cull water ripple / drip"), cfg.waterRippleCullEnabled)
				.setDefaultValue(true)
				.setTooltip(Component.literal("Reduces dripping water/lava and ripple particles."))
				.setSaveConsumer(v -> cfg.waterRippleCullEnabled = v).build());
		rendering.addEntry(e.startDoubleField(Component.literal("Water ripple keep chance"), cfg.waterRippleKeepChance)
				.setDefaultValue(0.15).setMin(0.0).setMax(1.0)
				.setSaveConsumer(v -> cfg.waterRippleKeepChance = v).build());

		rendering.addEntry(e.startBooleanToggle(Component.literal("Per-explosion particle cap"), cfg.explosionParticleCapEnabled)
				.setDefaultValue(true)
				.setTooltip(Component.literal("Limits particles per explosion burst so a single explosion can't spike the engine."))
				.setSaveConsumer(v -> cfg.explosionParticleCapEnabled = v).build());
		rendering.addEntry(e.startIntSlider(Component.literal("Max particles per explosion"), cfg.maxParticlesPerExplosion, 10, 300)
				.setDefaultValue(60)
				.setSaveConsumer(v -> cfg.maxParticlesPerExplosion = v).build());

		rendering.addEntry(e.startBooleanToggle(Component.literal("Skip far entity interpolation"), cfg.entityInterpolationSkipEnabled)
				.setDefaultValue(false)
				.setTooltip(Component.literal("OFF by default. Skips position lerp updates for very far entities — saves CPU but may cause brief pop-in."))
				.setSaveConsumer(v -> cfg.entityInterpolationSkipEnabled = v).build());
		rendering.addEntry(e.startDoubleField(Component.literal("Interpolation skip distance"), cfg.entityInterpolationSkipDistance)
				.setDefaultValue(48.0).setMin(16.0).setMax(256.0)
				.setSaveConsumer(v -> cfg.entityInterpolationSkipDistance = v).build());

		rendering.addEntry(e.startBooleanToggle(Component.literal("Reduce clouds under load"), cfg.cloudReductionEnabled)
				.setDefaultValue(true)
				.setTooltip(Component.literal("Halves or skips cloud rendering when FPS ladder is active or RAM+CPU pressure detected."))
				.setSaveConsumer(v -> cfg.cloudReductionEnabled = v).build());

		rendering.addEntry(e.startBooleanToggle(Component.literal("Skip entities in loading chunks"), cfg.unloadedChunkEntityCullEnabled)
				.setDefaultValue(true)
				.setTooltip(Component.literal("Hides entities whose chunk isn't fully loaded. Avoids pop-in render cost on weak CPUs."))
				.setSaveConsumer(v -> cfg.unloadedChunkEntityCullEnabled = v).build());

		rendering.addEntry(e.startBooleanToggle(Component.literal("Sodium sidebar page"), cfg.sodiumSidebarPageEnabled)
				.setDefaultValue(true)
				.setTooltip(Component.literal("Injects an HSN page into Sodium/Mercurizer/Embeddium sidebar (when installed)."))
				.setSaveConsumer(v -> cfg.sodiumSidebarPageEnabled = v).build());

		// --- 11 EXP ---
		ConfigCategory exp = builder.getOrCreateCategory(Component.literal("11 · HARDCORE EXP"));
		exp.addEntry(e.startTextDescription(Component.literal("Experimental. Keep OFF for normal play.")).build());
		exp.addEntry(e.startBooleanToggle(Component.literal("Enable hardcore EXP"), cfg.hardcoreExpEnabled)
				.setDefaultValue(false).setSaveConsumer(v -> cfg.hardcoreExpEnabled = v).build());
		exp.addEntry(e.startBooleanToggle(Component.literal("Vector cull path"), cfg.hardcoreVectorCull)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.hardcoreVectorCull = v).build());
		exp.addEntry(e.startBooleanToggle(Component.literal("Off-heap particle SoA"), cfg.hardcoreOffHeapSoa)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.hardcoreOffHeapSoa = v).build());
		exp.addEntry(e.startBooleanToggle(Component.literal("Lazy particle budget"), cfg.hardcoreLazyBudget)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.hardcoreLazyBudget = v).build());

		return builder.build();
	}
}
