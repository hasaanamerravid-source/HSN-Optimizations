package hsn.modod.client.mixin;

import hsn.modod.config.HSNConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Suppresses rendering of entities whose chunk has not yet reached FULL status
 * (i.e. the chunk is still loading/decorating). On weak CPUs, rendering entities
 * in partially-loaded chunks adds draw calls for geometry that then gets
 * immediately replaced by the chunk mesh, causing both a visual pop and a
 * redundant GPU upload. Skipping them avoids that entirely.
 *
 * Only applies to non-player entities (local player always renders).
 * Soft target (require = 0) — ChunkStatus constant names shifted in 1.20.5+.
 */
@Mixin(EntityRenderer.class)
public class UnloadedChunkEntityMixin {

	@Inject(
			method = "shouldRender(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/client/renderer/culling/Frustum;DDD)Z",
			at = @At("HEAD"),
			cancellable = true,
			require = 0
	)
	private void hsn$unloadedChunkCull(
			Entity entity,
			net.minecraft.client.renderer.culling.Frustum frustum,
			double camX, double camY, double camZ,
			CallbackInfoReturnable<Boolean> cir
	) {
		HSNConfig cfg = HSNConfig.get();
		if (!cfg.unloadedChunkEntityCullEnabled) return;
		if (entity == null) return;

		Minecraft client = Minecraft.getInstance();
		if (entity == client.player) return; // never cull local player
		if (entity instanceof Player) return; // don't cull other players

		var level = client.level;
		if (level == null) return;

		try {
			net.minecraft.world.level.ChunkPos cp = new net.minecraft.world.level.ChunkPos(entity.blockPosition());
			ChunkAccess chunk = level.getChunk(entity.getBlockX() >> 4, entity.getBlockZ() >> 4, ChunkStatus.FULL, false);
			if (chunk == null) {
				// Chunk not yet at FULL status — skip rendering
				cir.setReturnValue(false);
			}
		} catch (Throwable ignored) {
			// If ChunkStatus.FULL doesn't exist in this version, fail open
		}
	}
}
