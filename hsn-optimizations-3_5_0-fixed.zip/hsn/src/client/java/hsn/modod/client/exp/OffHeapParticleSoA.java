package hsn.modod.client.exp;

import hsn.modod.HSNOptimizations;

import java.lang.foreign.Arena;
import java.lang.foreign.MemorySegment;
import java.lang.foreign.ValueLayout;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Mini Structure-of-Arrays in off-heap memory (Panama FFM).
 * Stores recent particle positions only — does NOT replace Entity objects.
 */
public final class OffHeapParticleSoA {

	private static Arena arena;
	private static MemorySegment xs, ys, zs;
	private static int capacity = 0;
	private static final AtomicInteger writeHead = new AtomicInteger(0);
	private static final AtomicInteger recorded = new AtomicInteger(0);
	private static boolean ready = false;

	private OffHeapParticleSoA() {}

	public static boolean tryInit(int cap) {
		try {
			capacity = Math.max(256, Math.min(cap, 1 << 16));
			arena = Arena.ofShared();
			xs = arena.allocate(ValueLayout.JAVA_DOUBLE, capacity);
			ys = arena.allocate(ValueLayout.JAVA_DOUBLE, capacity);
			zs = arena.allocate(ValueLayout.JAVA_DOUBLE, capacity);
			writeHead.set(0);
			recorded.set(0);
			ready = true;
			HSNOptimizations.LOGGER.info("OffHeapParticleSoA: {} slots off-heap (FFM)", capacity);
			return true;
		} catch (Throwable t) {
			ready = false;
			HSNOptimizations.LOGGER.warn("OffHeapParticleSoA failed: {}", t.toString());
			return false;
		}
	}

	public static void record(double x, double y, double z) {
		if (!ready) return;
		try {
			int i = writeHead.getAndIncrement() & (capacity - 1); // capacity power-of-2 preferred
			if ((capacity & (capacity - 1)) != 0) {
				i = Math.floorMod(writeHead.get(), capacity);
			}
			xs.setAtIndex(ValueLayout.JAVA_DOUBLE, i, x);
			ys.setAtIndex(ValueLayout.JAVA_DOUBLE, i, y);
			zs.setAtIndex(ValueLayout.JAVA_DOUBLE, i, z);
			recorded.incrementAndGet();
		} catch (Throwable ignored) {}
	}

	public static boolean isReady() {
		return ready;
	}

	public static String stats() {
		if (!ready) return "SoA=n/a";
		return "SoA=" + capacity + " rec=" + recorded.get();
	}

	public static void shutdown() {
		try {
			if (arena != null) arena.close();
		} catch (Throwable ignored) {}
		ready = false;
	}
}
