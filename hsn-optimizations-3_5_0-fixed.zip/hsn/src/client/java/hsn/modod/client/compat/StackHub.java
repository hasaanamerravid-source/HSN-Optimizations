package hsn.modod.client.compat;

import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Detects common performance / companion mods for the About hub and F3.
 */
public final class StackHub {

	private StackHub() {}

	public static boolean loaded(String id) {
		return FabricLoader.getInstance().isModLoaded(id);
	}

	public static String versionOf(String id) {
		Optional<ModContainer> c = FabricLoader.getInstance().getModContainer(id);
		return c.map(m -> m.getMetadata().getVersion().getFriendlyString()).orElse("-");
	}

	public static List<String> statusLines() {
		List<String> lines = new ArrayList<>();
		lines.add(line("sodium", "Sodium"));
		lines.add(line("mercurizer", "Mercurizer"));
		lines.add(line("embeddium", "Embeddium"));
		lines.add(line("iris", "Iris"));
		lines.add(line("lithium", "Lithium"));
		lines.add(line("ferritecore", "FerriteCore"));
		lines.add(line("c2me", "C2ME"));
		lines.add(line("immediatelyfast", "ImmediatelyFast"));
		lines.add(line("entityculling", "EntityCulling"));
		lines.add(line("moreculling", "MoreCulling"));
		lines.add(line("cloth-config", "Cloth Config"));
		lines.add(line("modmenu", "Mod Menu"));
		return lines;
	}

	private static String line(String id, String label) {
		if (loaded(id)) return label + ": ON (" + versionOf(id) + ")";
		// cloth-config2 id
		if (id.equals("cloth-config") && (loaded("cloth-config2") || loaded("cloth_config"))) {
			return label + ": ON";
		}
		return label + ": —";
	}

	public static String summaryOneLine() {
		StringBuilder sb = new StringBuilder("HSN stack: ");
		boolean any = false;
		for (String id : new String[]{"sodium", "mercurizer", "embeddium", "lithium", "ferritecore", "c2me"}) {
			if (loaded(id)) {
				if (any) sb.append(" + ");
				sb.append(id);
				any = true;
			}
		}
		if (!any) sb.append("vanilla-ish (no Sodium/Lithium detected)");
		return sb.toString();
	}

	public static List<String> weakPcTips() {
		List<String> tips = new ArrayList<>();
		tips.add("Weak PC tips:");
		tips.add("• Preset ULTRA_LOW + Render Distance 8–12");
		tips.add("• Sodium: VSync OFF, max FPS high or unlimited");
		tips.add("• No shader packs on HD 4000/4600-class GPUs");
		tips.add("• JVM: see About tab / hsn-jvm-recommended.txt");
		tips.add("• Hotkeys: ULTRA_LOW and SAFE MODE (configurable)");
		if (!loaded("sodium") && !loaded("mercurizer") && !loaded("embeddium")) {
			tips.add("• Install Sodium or Mercurizer for the biggest FPS gain");
		}
		return tips;
	}
}
