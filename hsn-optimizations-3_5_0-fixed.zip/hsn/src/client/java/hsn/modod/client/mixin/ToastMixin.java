package hsn.modod.client.mixin;

import hsn.modod.config.HSNConfig;
import net.minecraft.client.gui.components.toasts.Toast;
import net.minecraft.client.gui.components.toasts.ToastManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Limits toast spam. Class name may be ToastComponent/ToastManager depending on mappings —
 * require=0 so missing target does not crash the game.
 */
@Mixin(ToastManager.class)
public class ToastMixin {

	@Inject(method = "addToast", at = @At("HEAD"), cancellable = true, require = 0)
	private void hsn$limitToasts(Toast toast, CallbackInfo ci) {
		HSNConfig cfg = HSNConfig.get();
		if (!cfg.toastLimitEnabled) return;
		try {
			// Soft limit: randomly drop when aggressive; hard queue check via reflection if available
			var listField = this.getClass().getDeclaredFields();
			int visible = 0;
			for (var f : listField) {
				if (java.util.List.class.isAssignableFrom(f.getType())) {
					f.setAccessible(true);
					Object v = f.get(this);
					if (v instanceof java.util.List<?> list) {
						visible = Math.max(visible, list.size());
					}
				}
			}
			if (visible >= Math.max(1, cfg.maxToasts)) {
				ci.cancel();
			}
		} catch (Throwable t) {
			// if we cannot inspect queue, drop ~50% when limit enabled under spam
			if (Math.random() > 0.5) {
				ci.cancel();
			}
		}
	}
}
