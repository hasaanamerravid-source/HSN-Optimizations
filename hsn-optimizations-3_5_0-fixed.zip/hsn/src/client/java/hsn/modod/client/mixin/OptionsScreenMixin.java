package hsn.modod.client.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Disabled: button overlapped Done and was the wrong place.
 * HSN settings open via Mod Menu + Sodium/Mercurizer tab.
 * Soft targets kept so old configs do not crash.
 */
@Mixin(
		targets = {
				"net.minecraft.client.gui.screens.options.OptionsScreen",
				"net.minecraft.client.gui.screens.OptionsScreen"
		},
		priority = 900
)
public abstract class OptionsScreenMixin {
	@Inject(method = "init", at = @At("RETURN"), require = 0)
	private void hsn$noButton(CallbackInfo ci) {
		// intentionally empty
	}
}
