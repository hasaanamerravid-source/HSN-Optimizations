package hsn.modod.client.optimize;

import hsn.modod.HSNOptimizations;
import hsn.modod.config.HSNConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;

/**
 * Optionally forces smooth lighting (ambient occlusion) off for FPS on weak GPUs.
 * Applied on client start and after config save.
 */
public final class SmoothLightingHelper {

	private SmoothLightingHelper() {}

	public static void applyFromConfig() {
		HSNConfig cfg = HSNConfig.get();
		Minecraft client = Minecraft.getInstance();
		if (client == null || client.options == null) return;

		try {
			// Mojmap 26.x: ambientOcclusion is an OptionInstance<Boolean> (or enum on older)
			OptionInstance<?> ao = client.options.ambientOcclusion();
			if (ao == null) return;

			if (cfg.disableSmoothLighting) {
				// Prefer false / OFF
				Object value = ao.get();
				if (value instanceof Boolean b) {
					if (b) {
						@SuppressWarnings("unchecked")
						OptionInstance<Boolean> boolAo = (OptionInstance<Boolean>) ao;
						boolAo.set(false);
						HSNOptimizations.LOGGER.info("Smooth lighting forced OFF (HSN config)");
					}
				} else {
					// Enum-style (e.g. AmbientOcclusionStatus) — set via string if possible
					HSNOptimizations.LOGGER.info(
							"Smooth lighting option type {} — set Graphics to Fast or disable AO in Video Settings",
							value != null ? value.getClass().getSimpleName() : "null");
				}
			}
		} catch (Throwable t) {
			HSNOptimizations.LOGGER.warn("Could not apply smooth lighting setting: {}", t.toString());
		}
	}
}
