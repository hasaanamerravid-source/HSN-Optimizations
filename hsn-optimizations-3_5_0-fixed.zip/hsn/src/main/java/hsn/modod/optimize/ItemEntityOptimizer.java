package hsn.modod.optimize;

import hsn.modod.config.HSNConfig;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Periodic aggressive item-entity merge using only public APIs.
 * Scans near online players to keep cost bounded.
 */
public final class ItemEntityOptimizer {

	private static int tickCounter = 0;

	private ItemEntityOptimizer() {}

	public static void init() {
		// 26.x: END_WORLD_TICK was renamed to END_LEVEL_TICK (ServerLevel)
		ServerTickEvents.END_LEVEL_TICK.register(ItemEntityOptimizer::onLevelTick);
	}

	private static void onLevelTick(ServerLevel level) {
		HSNConfig cfg = HSNConfig.get();
		if (!cfg.itemMergeEnabled) return;

		tickCounter++;
		if (tickCounter < Math.max(10, cfg.itemMergeIntervalTicks)) return;
		tickCounter = 0;

		double radius = cfg.itemMergeRadius;
		double scanRange = 48.0;
		Set<ItemEntity> visited = new HashSet<>();

		for (ServerPlayer player : level.players()) {
			AABB playerBox = player.getBoundingBox().inflate(scanRange);
			List<ItemEntity> items = level.getEntitiesOfClass(
					ItemEntity.class,
					playerBox,
					e -> e.isAlive() && !e.getItem().isEmpty()
			);

			for (ItemEntity a : items) {
				if (!visited.add(a) || !a.isAlive()) continue;

				ItemStack stackA = a.getItem();
				if (stackA.getCount() >= stackA.getMaxStackSize()) continue;

				AABB box = a.getBoundingBox().inflate(radius);
				List<ItemEntity> nearby = level.getEntitiesOfClass(
						ItemEntity.class,
						box,
						b -> b != a && b.isAlive() && !b.getItem().isEmpty()
				);

				for (ItemEntity b : nearby) {
					if (!a.isAlive()) break;
					ItemStack stackB = b.getItem();
					if (!ItemStack.isSameItemSameComponents(stackA, stackB)) continue;

					int space = stackA.getMaxStackSize() - stackA.getCount();
					if (space <= 0) break;

					int move = Math.min(space, stackB.getCount());
					stackA.grow(move);
					a.setItem(stackA);
					stackB.shrink(move);
					if (stackB.isEmpty()) {
						b.discard();
					} else {
						b.setItem(stackB);
					}
				}
			}
		}
	}
}