# Precise JVM RAM allocation for HSN-Optimizations

Use these with Prism Launcher / MultiMC / official launcher (JVM Arguments box).
Java **25** is required (same as this mod).

## Rules of thumb

| System RAM | `-Xms` (start) | `-Xmx` (max) | Notes |
|------------|----------------|--------------|--------|
| 4 GB total | 1G | 2G | Leave ~2G for OS + GPU shared memory (Intel HD) |
| 6 GB total | 1536M | 3G | |
| 8 GB total | 2G | 4G | Good default for low-end laptops |
| 12 GB total | 3G | 6G | |
| 16 GB total | 4G | 8G | Do **not** give Minecraft all RAM |

**Never** set `-Xmx` higher than about half of system RAM on integrated GPUs
(Intel HD / AMD Vega share system memory).

## Recommended full argument sets

### Ultra-low (4 GB machine, Intel HD 4000/4600 class)

```
-Xms1G -Xmx2G -XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200 -XX:+UnlockExperimentalVMOptions -XX:+DisableExplicitGC -XX:G1NewSizePercent=20 -XX:G1MaxNewSizePercent=40 -XX:G1HeapRegionSize=8M -XX:G1ReservePercent=20 -XX:InitiatingHeapOccupancyPercent=15 -XX:G1MixedGCLiveThresholdPercent=90 -XX:G1HeapWastePercent=5 -XX:GCTimeRatio=4 -Dfile.encoding=UTF-8
```

### Low (6–8 GB)

```
-Xms2G -Xmx4G -XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200 -XX:+UnlockExperimentalVMOptions -XX:+DisableExplicitGC -XX:G1NewSizePercent=30 -XX:G1MaxNewSizePercent=40 -XX:G1HeapRegionSize=16M -XX:G1ReservePercent=20 -XX:InitiatingHeapOccupancyPercent=15 -Dfile.encoding=UTF-8
```

### Balanced (12–16 GB)

```
-Xms3G -Xmx6G -XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=150 -XX:+UnlockExperimentalVMOptions -XX:G1HeapRegionSize=16M -Dfile.encoding=UTF-8
```

## Optional (Java 25)

If your CPU has many cores and you want lower pause times:

```
-XX:+UseZGC -Xms2G -Xmx4G
```

ZGC uses more native memory outside the heap; keep `-Xmx` a bit lower on 8 GB machines.

## C2ME (real concurrent chunk loading)

HSN does **not** replace C2ME. For multi-threaded worldgen / chunk loading install:

- [C2ME](https://modrinth.com/mod/c2me-fabric) (Fabric)

HSN handles particles + entity render distance; C2ME handles chunk generation threads.
They work together.

## Prism Launcher

1. Instance → Settings → Java
2. Paste one of the argument blocks above into **JVM arguments**
3. Set Max memory to match `-Xmx` (Prism also has a slider — keep them consistent)
