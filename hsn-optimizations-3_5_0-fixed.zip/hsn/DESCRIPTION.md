# HSN-Optimizations 3.4.0

Client performance pack for **weak / pre-2015 GPUs** on **Fabric Minecraft 26.2**.

## Not a Sodium replacement
Install **Sodium** or **Mercurizer** for terrain/meshing. HSN fills gaps: particles, far entities, adaptive load, presets, hotkeys.

## Hotkeys
| Key | Action |
|-----|--------|
| **F8** | Apply ULTRA_LOW preset |
| **F9** | Apply SAFE MODE |
| **F7** | Toggle FPS overlay badge |

## Hub
Config → **About / Hub** lists detected performance mods and weak-PC tips.

## JVM (8 GB example)
```
-Xms1536M -Xmx3072M -XX:+UseG1GC -XX:MaxGCPauseMillis=50
```
See `scripts/jvm-8gb-g1.txt`.

## Honest FPS note
Gains depend on scene and stack. HSN cannot match a full renderer rewrite.
