# HSN tab in Sodium / Mercurizer

True left-sidebar **pages** (like Iris) need compile-time Sodium API matching the exact Mercurizer fork.

This build adds a soft **HSN Optimizations** button on the Sodium/Mercurizer options GUI when that class exists, and full settings via:

- Mod Menu → HSN-Optimizations
- Cloth Config categories: MAX, Sodium-style / Net, etc.

Vanilla Options bottom button was removed (it overlapped Done).
