package hsn.modod.client.config;

import hsn.modod.config.HSNConfig;
import hsn.modod.config.HSNConfig.Preset;
import hsn.modod.config.HSNPresets;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Cloth Config screen — only the remaining real options.
 */
public final class HSNConfigScreen {

	private HSNConfigScreen() {
	}

	public static Screen create(Screen parent) {
		HSNConfig cfg = HSNConfig.get();
		ConfigBuilder builder = ConfigBuilder.create()
				.setParentScreen(parent)
				.setTitle(Component.literal("HSN Optimizations"))
				.setSavingRunnable(cfg::save);

		ConfigEntryBuilder e = builder.entryBuilder();

		// General
		ConfigCategory gen = builder.getOrCreateCategory(Component.literal("General"));
		gen.addEntry(e.startTextDescription(Component.literal(
				"Lightweight client culling for weak hardware. Use with Sodium when available.")).build());
		gen.addEntry(e.startTextDescription(Component.literal(
				"Hotkeys: F7 = FPS overlay · F8 = ULTRA_LOW · F9 = SAFE")).build());
		gen.addEntry(e.startEnumSelector(Component.literal("Performance preset"), Preset.class, cfg.lastAppliedPreset)
				.setDefaultValue(Preset.BALANCED)
				.setTooltip(Component.literal("Applies a balanced set of distances and keep rates."))
				.setSaveConsumer(v -> {
					cfg.lastAppliedPreset = v;
					HSNPresets.apply(cfg, v);
				}).build());
		gen.addEntry(e.startBooleanToggle(Component.literal("Show HSN status on F3"), cfg.f3ShowStatus)
				.setDefaultValue(true)
				.setSaveConsumer(v -> cfg.f3ShowStatus = v).build());
		gen.addEntry(e.startBooleanToggle(Component.literal("FPS overlay"), cfg.fpsOverlayEnabled)
				.setDefaultValue(false)
				.setSaveConsumer(v -> cfg.fpsOverlayEnabled = v).build());

		// Particles
		ConfigCategory particles = builder.getOrCreateCategory(Component.literal("Particles"));
		particles.addEntry(e.startBooleanToggle(Component.literal("Particle culling"), cfg.particleCullingEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.particleCullingEnabled = v).build());
		particles.addEntry(e.startIntField(Component.literal("Max particles (soft)"), cfg.maxParticles)
				.setDefaultValue(400).setMin(50).setMax(2000)
				.setSaveConsumer(v -> cfg.maxParticles = v).build());
		particles.addEntry(e.startDoubleField(Component.literal("Max particle distance"), cfg.maxParticleDistance)
				.setDefaultValue(16.0).setMin(4.0).setMax(64.0)
				.setSaveConsumer(v -> cfg.maxParticleDistance = v).build());
		particles.addEntry(e.startDoubleField(Component.literal("Rain keep chance"), cfg.rainKeepChance)
				.setDefaultValue(0.15).setMin(0.0).setMax(1.0)
				.setSaveConsumer(v -> cfg.rainKeepChance = v).build());
		particles.addEntry(e.startDoubleField(Component.literal("Smoke keep chance"), cfg.smokeKeepChance)
				.setDefaultValue(0.25).setMin(0.0).setMax(1.0)
				.setSaveConsumer(v -> cfg.smokeKeepChance = v).build());

		// Entities
		ConfigCategory entities = builder.getOrCreateCategory(Component.literal("Entities"));
		entities.addEntry(e.startBooleanToggle(Component.literal("Entity culling"), cfg.entityCullingEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.entityCullingEnabled = v).build());
		entities.addEntry(e.startDoubleField(Component.literal("Max entity distance"), cfg.maxEntityRenderDistance)
				.setDefaultValue(32.0).setMin(8.0).setMax(128.0)
				.setSaveConsumer(v -> cfg.maxEntityRenderDistance = v).build());
		entities.addEntry(e.startDoubleField(Component.literal("Max item entity distance"), cfg.maxItemEntityRenderDistance)
				.setDefaultValue(20.0).setMin(4.0).setMax(64.0)
				.setSaveConsumer(v -> cfg.maxItemEntityRenderDistance = v).build());
		entities.addEntry(e.startDoubleField(Component.literal("Max XP orb distance"), cfg.maxXpOrbRenderDistance)
				.setDefaultValue(16.0).setMin(4.0).setMax(48.0)
				.setSaveConsumer(v -> cfg.maxXpOrbRenderDistance = v).build());
		entities.addEntry(e.startBooleanToggle(Component.literal("Shadow culling"), cfg.shadowCullingEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.shadowCullingEnabled = v).build());
		entities.addEntry(e.startDoubleField(Component.literal("Max shadow distance"), cfg.maxShadowDistance)
				.setDefaultValue(12.0).setMin(2.0).setMax(32.0)
				.setSaveConsumer(v -> cfg.maxShadowDistance = v).build());
		entities.addEntry(e.startBooleanToggle(Component.literal("Name tag culling"), cfg.nameTagCullEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.nameTagCullEnabled = v).build());
		entities.addEntry(e.startDoubleField(Component.literal("Max name tag distance"), cfg.maxNameTagDistance)
				.setDefaultValue(24.0).setMin(4.0).setMax(64.0)
				.setSaveConsumer(v -> cfg.maxNameTagDistance = v).build());

		// Block entities & sound
		ConfigCategory other = builder.getOrCreateCategory(Component.literal("Other"));
		other.addEntry(e.startBooleanToggle(Component.literal("Block entity culling"), cfg.blockEntityCullingEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.blockEntityCullingEnabled = v).build());
		other.addEntry(e.startDoubleField(Component.literal("Max block entity distance"), cfg.maxBlockEntityRenderDistance)
				.setDefaultValue(24.0).setMin(4.0).setMax(64.0)
				.setSaveConsumer(v -> cfg.maxBlockEntityRenderDistance = v).build());
		other.addEntry(e.startBooleanToggle(Component.literal("Sound distance culling"), cfg.soundDistanceCullingEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.soundDistanceCullingEnabled = v).build());
		other.addEntry(e.startDoubleField(Component.literal("Max sound distance"), cfg.maxSoundDistance)
				.setDefaultValue(24.0).setMin(4.0).setMax(64.0)
				.setSaveConsumer(v -> cfg.maxSoundDistance = v).build());
		other.addEntry(e.startBooleanToggle(Component.literal("Weather sound reduction"), cfg.weatherSoundReductionEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.weatherSoundReductionEnabled = v).build());
		other.addEntry(e.startBooleanToggle(Component.literal("Item merge (server)"), cfg.itemMergeEnabled)
				.setDefaultValue(true).setSaveConsumer(v -> cfg.itemMergeEnabled = v).build());

		return builder.build();
	}
}
