package hsn.optimizations.client.mixin;

import hsn.optimizations.client.optimize.AdaptiveCuller;
import hsn.optimizations.client.optimize.CullStats;
import hsn.optimizations.config.HSNConfig;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Strips the glowing outline from distant entities after vanilla fills render state.
 * Does not hide the entity itself — only clears outlineColor / glowing on the state.
 */
@Mixin(EntityRenderer.class)
public class GlowOutlineMixin {

	@Inject(
			method = "extractRenderState(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/client/renderer/entity/state/EntityRenderState;F)V",
			at = @At("RETURN"),
			require = 0
	)
	private void hsn$cullDistantGlow(Entity entity, EntityRenderState state, float partialTick, CallbackInfo ci) {
		HSNConfig cfg = HSNConfig.get();
		if (!cfg.modEnabled) {
			return;
		}
		if (!cfg.glowOutlineCullingEnabled || entity == null || state == null) {
			return;
		}
		if (!state.appearsGlowing()) {
			return;
		}
		double limit = cfg.maxGlowOutlineDistance * AdaptiveCuller.getScale();
		if (state.distanceToCameraSq > limit * limit) {
			state.outlineColor = EntityRenderState.NO_OUTLINE;
			CullStats.entitySkip();
		}
	}
}
