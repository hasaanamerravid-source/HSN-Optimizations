package hsn.optimizations.client.optimize;

import hsn.optimizations.config.HSNConfig;
import net.minecraft.client.Minecraft;

/**
 * Scales entity render distances based on live FPS.
 * Below target FPS -> eases distances down toward minAdaptiveScale.
 * At/above target FPS -> eases back up toward 1.0 (full distance).
 *
 * Also drives the "Weak GPU" auto layer: when smoothed FPS stays low
 * for a sustained period, extra-aggressive rules become active.
 */
public final class AdaptiveCuller {

    private static volatile int instantFps = 60;
    private static volatile double smoothedFps = 60.0;
    private static volatile double scale = 1.0;
    private static volatile boolean weakGpuActive = false;
    
    private static int lowFpsStreak = 0;
    private static volatile int lastReportedVanillaFps = -1;

    private AdaptiveCuller() {
    }

    public static void tick() {
        HSNConfig cfg = HSNConfig.get();
        if (cfg == null || !cfg.modEnabled) {
            scale = 1.0;
            weakGpuActive = false;
            hsn.optimizations.optimize.HotPath.publishScale(1.0);
            return;
        }

        int fps = -1;
        try {
            Minecraft client = Minecraft.getInstance();
            if (client != null) {
                fps = client.getFps();
            }
        } catch (Throwable ignored) {
        }
        int measured = FrameTime.fps();
        if (fps <= 0 && measured > 0) {
            fps = measured;
        } else if (fps > 0 && measured > 0) {
            // Blend the 1 Hz vanilla counter with the real frame-time estimate.
            fps = (int) Math.round(fps * 0.35 + measured * 0.65);
        }

        if (fps > 0) {
            instantFps = fps;
            if (fps != lastReportedVanillaFps) {
                lastReportedVanillaFps = fps;
                smoothedFps += (fps - smoothedFps) * 0.2;
            } else {
                smoothedFps += (fps - smoothedFps) * 0.08;
            }
        }

        // Sanitize configuration inputs to avoid clamp inversion errors (min > max)
        double minScale = clamp(cfg.minAdaptiveScale, 0.05, 1.0);
        double targetFps = Math.max(10.0, cfg.targetFps);

        // Weak-GPU auto detection
        if (cfg.weakGpuAutoEnabled) {
            if (smoothedFps < cfg.weakGpuFpsThreshold) {
                lowFpsStreak = Math.min(200, lowFpsStreak + 1);
            } else {
                lowFpsStreak = Math.max(0, lowFpsStreak - 2);
            }
            // Activate after ~3 seconds (60 ticks) of sustained low FPS
            weakGpuActive = lowFpsStreak > 60;
        } else {
            weakGpuActive = false;
            lowFpsStreak = 0;
        }

        // Adaptive culling is the full scaler. Performance mode still eases
        // distances when FPS dips, but never below 70% of the slider.
        if (!cfg.adaptiveCullingEnabled && !cfg.performanceModeEnabled) {
            if (scale != 1.0) {
                scale = 1.0;
                hsn.optimizations.optimize.HotPath.publishScale(1.0);
            }
            LowEndTuner.tick();
            return;
        }

        double floor = cfg.adaptiveCullingEnabled ? minScale : Math.max(0.70, minScale);
        double desired = clamp(smoothedFps / targetFps, floor, 1.0);

        // When weak-GPU layer is active, bias the target scale down by 15%
        if (weakGpuActive && cfg.adaptiveCullingEnabled) {
            desired = Math.min(desired, Math.max(floor, desired * 0.85));
        }

        // Smoothly ease scale toward target value to prevent frame-to-frame popping
        double currentScale = scale;
        currentScale += (desired - currentScale) * 0.08;
        scale = clamp(currentScale, floor, 1.0);
        hsn.optimizations.optimize.HotPath.publishScale(scale);
        LowEndTuner.tick();
    }

    public static double getScale() {
        return scale;
    }

    public static double getSmoothedFps() {
        return smoothedFps;
    }

    public static int getInstantFps() {
        return instantFps;
    }

    /** True when the auto weak-GPU layer has engaged. */
    public static boolean isWeakGpuActive() {
        return weakGpuActive;
    }

    private static double clamp(double v, double min, double max) {
        if (min > max) {
            return max;
        }
        return Math.max(min, Math.min(max, v));
    }
}