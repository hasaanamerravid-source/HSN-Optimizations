package hsn.optimizations.optimize;

import java.util.concurrent.atomic.AtomicLong;

/**
 * Counts pathfinding ticks skipped in the last second (common side).
 */
public final class PathfindingStats {

	private static final AtomicLong skipped = new AtomicLong();
	// Written on the integrated-server thread, read from the client F3 overlay.
	private static volatile long windowStart = System.currentTimeMillis();
	private static volatile long rate;

	private PathfindingStats() {
	}

	public static void tickSkipped() {
		skipped.incrementAndGet();
	}

	public static void tick() {
		long now = System.currentTimeMillis();
		if (now - windowStart >= 1000L) {
			rate = skipped.getAndSet(0);
			windowStart = now;
		}
	}

	public static long skippedPerSec() {
		return rate;
	}
}
