package hsn.modod.client;

import hsn.modod.HSNOptimizations;
import hsn.modod.client.compat.SodiumCompat;
import hsn.modod.client.optimize.AdaptivePerformance;
import hsn.modod.client.optimize.IdleMemoryTrim;
import hsn.modod.client.optimize.PreferOpenGLHelper;
import hsn.modod.client.optimize.SmoothLightingHelper;
import hsn.modod.client.optimize.VanillaGraphicsHelper;
import hsn.modod.config.HSNConfig;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public class HSNOptimizationsClient implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		HSNConfig cfg = HSNConfig.get();

		SodiumCompat.init();
		IdleMemoryTrim.init();
		AdaptivePerformance.init();
		PreferOpenGLHelper.applyFromConfig();
		SmoothLightingHelper.applyFromConfig();

		// Vanilla graphics once the client is ready
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (client.level != null) {
				VanillaGraphicsHelper.applyOnce();
			}
		});

		HSNOptimizations.LOGGER.info("HSN-Optimizations 2.1.0 ready — preset {}", cfg.lastAppliedPreset);
		HSNOptimizations.LOGGER.info(
				"Target: pre-2015 / weak iGPU (Intel HD 4000-class). Prefer OpenGL={}, autoVanilla={}",
				cfg.preferOpenGl, cfg.autoTuneVanillaGraphics);
	}
}
