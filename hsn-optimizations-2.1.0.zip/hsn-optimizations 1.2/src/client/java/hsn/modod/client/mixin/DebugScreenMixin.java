package hsn.modod.client.mixin;

import hsn.modod.client.compat.SodiumCompat;
import hsn.modod.client.optimize.AdaptivePerformance;
import hsn.modod.config.HSNConfig;
import net.minecraft.client.gui.components.DebugScreenOverlay;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

@Mixin(DebugScreenOverlay.class)
public class DebugScreenMixin {

	@Inject(method = "getGameInformation", at = @At("RETURN"), require = 0)
	private void hsn$f3Brand(CallbackInfoReturnable<List<String>> cir) {
		List<String> list = cir.getReturnValue();
		if (list == null) return;
		try {
			String brand = SodiumCompat.getF3Line();
			if (brand == null || brand.isEmpty()) {
				brand = "HSN-Optimizations 2.1.0";
			}

			// Insert directly under Mercurizer / Sodium / Embeddium line
			int insertAt = -1;
			for (int i = 0; i < list.size(); i++) {
				String s = list.get(i);
				if (s == null) continue;
				String lower = s.toLowerCase();
				if (lower.contains("mercurizer") || lower.contains("sodium") || lower.contains("embeddium")) {
					insertAt = i + 1;
					break;
				}
			}

			if (insertAt >= 0 && insertAt <= list.size()) {
				list.add(insertAt, brand);
			} else {
				list.add(brand);
			}

			HSNConfig cfg = HSNConfig.get();
			if (cfg.f3ShowAdaptiveStatus) {
				String ram = AdaptivePerformance.isRamPressure() ? "RAM!" : "ok";
				String cpu = AdaptivePerformance.isCpuPressure() ? "CPU!" : "ok";
				String adaptive = "HSN adaptive: " + ram + " / " + cpu;
				int after = insertAt >= 0 ? insertAt + 1 : list.size();
				if (after > list.size()) after = list.size();
				list.add(after, adaptive);
			}
		} catch (Throwable ignored) {}
	}
}
