package hsn.modod.client.mixin;

import hsn.modod.config.HSNConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.decoration.ItemFrame;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderer.class)
public class EntityRendererMixin {

	@Inject(
			method = "shouldRender(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/client/renderer/culling/Frustum;DDD)Z",
			at = @At("HEAD"),
			cancellable = true
	)
	private void hsn$entityDistanceCull(
			Entity entity,
			net.minecraft.client.renderer.culling.Frustum frustum,
			double camX, double camY, double camZ,
			CallbackInfoReturnable<Boolean> cir
	) {
		HSNConfig cfg = HSNConfig.get();
		if (!cfg.entityCullingEnabled) return;

		Minecraft client = Minecraft.getInstance();
		if (entity == client.player) return;

		Player player = client.player;
		if (player == null) return;

		double dx = entity.getX() - player.getX();
		double dy = entity.getY() - player.getY();
		double dz = entity.getZ() - player.getZ();
		double distSq = dx * dx + dy * dy + dz * dz;

		double limitSq;
		if (cfg.decorationEntityStrictDistance
				&& (entity instanceof ArmorStand || entity instanceof ItemFrame)) {
			limitSq = cfg.maxDecorationEntityDistanceSq();
		} else if (entity instanceof ItemEntity) {
			limitSq = cfg.maxItemEntityRenderDistanceSq();
		} else if (entity instanceof ExperienceOrb) {
			limitSq = cfg.maxXpOrbRenderDistanceSq();
		} else {
			limitSq = cfg.maxEntityRenderDistanceSq();
		}

		if (distSq > limitSq) {
			cir.setReturnValue(false);
		}
	}
}
