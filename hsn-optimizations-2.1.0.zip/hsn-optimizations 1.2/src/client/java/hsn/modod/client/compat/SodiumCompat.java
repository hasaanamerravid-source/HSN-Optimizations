package hsn.modod.client.compat;

import hsn.modod.HSNOptimizations;
import net.fabricmc.loader.api.FabricLoader;

/**
 * Detects Sodium / Embeddium and builds the F3 branding line.
 *
 * HSN does not replace Sodium. It runs alongside it (Mercurizer-style addon model):
 * Sodium owns terrain meshing; HSN owns particle + entity distance culling.
 */
public final class SodiumCompat {

	private static boolean sodiumLoaded;
	private static boolean embeddiumLoaded;
	private static boolean c2meLoaded;

	private SodiumCompat() {}

	public static void init() {
		FabricLoader loader = FabricLoader.getInstance();
		sodiumLoaded = loader.isModLoaded("sodium");
		embeddiumLoaded = loader.isModLoaded("embeddium");
		c2meLoaded = loader.isModLoaded("c2me");

		if (sodiumLoaded) {
			HSNOptimizations.LOGGER.info(
					"Sodium detected — HSN culling runs alongside Sodium Renderer. " +
					"Configure HSN via Mod Menu (not Sodium video settings).");
		} else if (embeddiumLoaded) {
			HSNOptimizations.LOGGER.info(
					"Embeddium detected — HSN culling runs alongside Embeddium.");
		} else {
			HSNOptimizations.LOGGER.info("No Sodium/Embeddium — standalone mode.");
		}

		if (c2meLoaded) {
			HSNOptimizations.LOGGER.info(
					"C2ME detected — compatible. HSN does not replace C2ME; use both.");
		}
	}

	public static boolean isSodiumLoaded() {
		return sodiumLoaded;
	}

	public static boolean isEmbeddiumLoaded() {
		return embeddiumLoaded;
	}

	public static boolean isC2meLoaded() {
		return c2meLoaded;
	}

	/** Line shown near the top of the F3 debug overlay. */
	public static String getF3Line() {
		String version = "2.1.0";
		// Shown under Mercurizer/Sodium on F3
		if (sodiumLoaded || embeddiumLoaded) {
			return "HSN-Optimizations " + version;
		}
		return "HSN-Optimizations " + version + " Renderer";
	}
}
