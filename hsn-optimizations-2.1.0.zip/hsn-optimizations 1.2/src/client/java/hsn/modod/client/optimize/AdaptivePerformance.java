package hsn.modod.client.optimize;

import hsn.modod.HSNOptimizations;
import hsn.modod.config.HSNConfig;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;

/**
 * Lightweight adaptive limiter for RAM and CPU.
 * Does not touch the light engine (Sodium/Starlight territory).
 * Only tightens particle caps / reports pressure when heap or frame time is bad.
 */
public final class AdaptivePerformance {

	private static long lastFrameNanos = 0L;
	private static double smoothedFrameMs = 16.0;
	private static boolean ramPressure = false;
	private static boolean cpuPressure = false;
	private static int logCooldown = 0;

	private AdaptivePerformance() {}

	public static void init() {
		ClientTickEvents.END_CLIENT_TICK.register(AdaptivePerformance::onTick);
	}

	private static void onTick(Minecraft client) {
		HSNConfig cfg = HSNConfig.get();
		if (!cfg.adaptiveRamEnabled && !cfg.adaptiveCpuEnabled) {
			ramPressure = false;
			cpuPressure = false;
			return;
		}

		// --- RAM ---
		if (cfg.adaptiveRamEnabled) {
			Runtime rt = Runtime.getRuntime();
			long free = rt.freeMemory();
			long total = rt.totalMemory();
			double freeRatio = total <= 0 ? 1.0 : (double) free / (double) total;
			boolean now = freeRatio < cfg.adaptiveRamThreshold;
			if (now != ramPressure && logCooldown <= 0) {
				HSNOptimizations.LOGGER.info(
						"Adaptive RAM {}: freeRatio={}% (threshold={}%)",
						now ? "ON" : "OFF",
						Math.round(freeRatio * 100),
						Math.round(cfg.adaptiveRamThreshold * 100));
				logCooldown = 100;
			}
			ramPressure = now;
		} else {
			ramPressure = false;
		}

		// --- CPU (frame time) ---
		if (cfg.adaptiveCpuEnabled) {
			long nowNanos = System.nanoTime();
			if (lastFrameNanos > 0) {
				double frameMs = (nowNanos - lastFrameNanos) / 1_000_000.0;
				// Ignore huge pauses (background / load)
				if (frameMs < 500) {
					smoothedFrameMs = smoothedFrameMs * 0.9 + frameMs * 0.1;
				}
			}
			lastFrameNanos = nowNanos;
			boolean nowCpu = smoothedFrameMs > cfg.adaptiveCpuFrameMs;
			if (nowCpu != cpuPressure && logCooldown <= 0) {
				HSNOptimizations.LOGGER.info(
						"Adaptive CPU {}: frame~{}ms (threshold={}ms)",
						nowCpu ? "ON" : "OFF",
						Math.round(smoothedFrameMs),
						Math.round(cfg.adaptiveCpuFrameMs));
				logCooldown = 100;
			}
			cpuPressure = nowCpu;
		} else {
			cpuPressure = false;
		}

		if (logCooldown > 0) logCooldown--;
	}

	public static boolean isRamPressure() {
		return ramPressure;
	}

	public static boolean isCpuPressure() {
		return cpuPressure;
	}

	/** Effective particle cap after adaptive factors. */
	public static int effectiveMaxParticles() {
		HSNConfig cfg = HSNConfig.get();
		int base = Math.max(50, cfg.maxParticles);
		double factor = 1.0;
		if (ramPressure) {
			factor *= Math.max(0.2, cfg.adaptiveParticleFactor);
		}
		if (cpuPressure) {
			factor *= 0.7;
		}
		return Math.max(40, (int) (base * factor));
	}

	public static double effectiveShadowDistanceSq() {
		HSNConfig cfg = HSNConfig.get();
		double d = cfg.maxShadowDistance;
		if (ramPressure || cpuPressure) {
			d *= 0.65;
		}
		return d * d;
	}
}
