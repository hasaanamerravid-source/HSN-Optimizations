package hsn.modod.client.config;

import hsn.modod.client.optimize.SmoothLightingHelper;
import hsn.modod.config.HSNConfig;
import hsn.modod.config.HSNConfig.Preset;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import hsn.modod.client.config.HSNHomeScreen.Section;

/**
 * Builds the in-game Cloth Config screen with presets + all fine-tune sliders.
 */
public final class HSNConfigScreen {

	private HSNConfigScreen() {}

	/** Mod Menu entry — Cloth Config with About/README first. */
	public static Screen create(Screen parent) {
		return buildCloth(parent, null);
	}

	public static Screen createFull(Screen parent) {
		return buildCloth(parent, null);
	}

	public static Screen createForSection(Screen parent, Section section) {
		return buildCloth(parent, section);
	}

	private static Screen buildCloth(Screen parent, Section only) {
		HSNConfig cfg = HSNConfig.get();

		ConfigBuilder builder = ConfigBuilder.create()
				.setParentScreen(parent)
				.setTitle(Component.translatable("text.hsn-optimizations.config.title"))
				.setSavingRunnable(() -> {
				cfg.onSaved();
				SmoothLightingHelper.applyFromConfig();
			});

		ConfigEntryBuilder entry = builder.entryBuilder();

		// ===== About / README (first tab) =====
		ConfigCategory about = builder.getOrCreateCategory(Component.literal("About"));
		about.addEntry(entry.startTextDescription(Component.literal(
				"HSN-Optimizations — for pre-2015 / weak iGPUs (Intel HD 4000/4600-class).")).build());
		about.addEntry(entry.startTextDescription(Component.literal(
				"Cuts particles, far entities, shadows. Adaptive RAM/CPU.")).build());
		about.addEntry(entry.startTextDescription(Component.literal(
				"Recommended: Sodium (OpenGL) + this mod + C2ME. Use preset ULTRA_LOW or LOW.")).build());
		about.addEntry(entry.startTextDescription(Component.literal(
				"SMP/PvP: raise entity distance to 80-128 or disable entity culling.")).build());
		about.addEntry(entry.startTextDescription(Component.literal(
				"Tabs on the left: Presets, Particles, Entities, Items, Memory, Extra / Safe.")).build());

		// ===== Presets =====
		ConfigCategory presets = builder.getOrCreateCategory(
				Component.translatable("text.hsn-optimizations.config.category.presets"));

		presets.addEntry(entry.startEnumSelector(
						Component.translatable("text.hsn-optimizations.config.preset"),
						Preset.class,
						cfg.lastAppliedPreset)
				.setDefaultValue(Preset.ULTRA_LOW)
				.setEnumNameProvider(v -> Component.translatable(
						"text.hsn-optimizations.config.preset.value." + v.name().toLowerCase()))
				.setTooltip(Component.translatable("text.hsn-optimizations.config.preset.tooltip"))
				.setSaveConsumer(v -> cfg.lastAppliedPreset = v)
				.build());

		presets.addEntry(entry.startBooleanToggle(
						Component.translatable("text.hsn-optimizations.config.apply_preset"),
						cfg.applySelectedPreset)
				.setDefaultValue(false)
				.setTooltip(Component.translatable("text.hsn-optimizations.config.apply_preset.tooltip"))
				.setSaveConsumer(v -> cfg.applySelectedPreset = v)
				.build());

		// Quick-apply buttons via enum is enough; user checks "Apply" and hits Done.
		// Also expose one-click preset helpers as boolean triggers that apply immediately on save.
		presets.addEntry(entry.startTextDescription(
				Component.translatable("text.hsn-optimizations.config.preset.help")).build());

		// ===== Particles =====
		ConfigCategory particles = builder.getOrCreateCategory(
				Component.translatable("text.hsn-optimizations.config.category.particles"));

		particles.addEntry(entry.startBooleanToggle(
						Component.translatable("text.hsn-optimizations.config.particle_culling"),
						cfg.particleCullingEnabled)
				.setDefaultValue(true)
				.setSaveConsumer(v -> cfg.particleCullingEnabled = v)
				.build());

		particles.addEntry(entry.startIntSlider(
						Component.translatable("text.hsn-optimizations.config.max_particles"),
						cfg.maxParticles, 50, 8000)
				.setDefaultValue(700)
				.setTooltip(Component.translatable("text.hsn-optimizations.config.max_particles.tooltip"))
				.setSaveConsumer(v -> cfg.maxParticles = v)
				.build());

		particles.addEntry(entry.startDoubleField(
						Component.translatable("text.hsn-optimizations.config.max_particle_distance"),
						cfg.maxParticleDistance)
				.setDefaultValue(24.0)
				.setMin(4.0).setMax(256.0)
				.setSaveConsumer(v -> cfg.maxParticleDistance = v)
				.build());

		particles.addEntry(entry.startDoubleField(
						Component.translatable("text.hsn-optimizations.config.rain_keep_chance"),
						cfg.rainKeepChance)
				.setDefaultValue(0.18)
				.setMin(0.0).setMax(1.0)
				.setTooltip(Component.translatable("text.hsn-optimizations.config.rain_keep_chance.tooltip"))
				.setSaveConsumer(v -> cfg.rainKeepChance = v)
				.build());

		particles.addEntry(entry.startDoubleField(
						Component.translatable("text.hsn-optimizations.config.smoke_keep_chance"),
						cfg.smokeKeepChance)
				.setDefaultValue(0.25)
				.setMin(0.0).setMax(1.0)
				.setSaveConsumer(v -> cfg.smokeKeepChance = v)
				.build());

		particles.addEntry(entry.startDoubleField(
						Component.translatable("text.hsn-optimizations.config.heavy_keep_chance"),
						cfg.heavyParticleKeepChance)
				.setDefaultValue(0.20)
				.setMin(0.0).setMax(1.0)
				.setTooltip(Component.translatable("text.hsn-optimizations.config.heavy_keep_chance.tooltip"))
				.setSaveConsumer(v -> cfg.heavyParticleKeepChance = v)
				.build());

		particles.addEntry(entry.startBooleanToggle(
						Component.translatable("text.hsn-optimizations.config.light_particle_culling"),
						cfg.lightParticleCullingEnabled)
				.setDefaultValue(true)
				.setTooltip(Component.translatable("text.hsn-optimizations.config.light_particle_culling.tooltip"))
				.setSaveConsumer(v -> cfg.lightParticleCullingEnabled = v)
				.build());

		particles.addEntry(entry.startDoubleField(
						Component.translatable("text.hsn-optimizations.config.light_particle_keep"),
						cfg.lightParticleKeepChance)
				.setDefaultValue(0.15)
				.setMin(0.0).setMax(1.0)
				.setSaveConsumer(v -> cfg.lightParticleKeepChance = v)
				.build());

		// ===== Entities =====
		ConfigCategory entities = builder.getOrCreateCategory(
				Component.translatable("text.hsn-optimizations.config.category.entities"));

		entities.addEntry(entry.startBooleanToggle(
						Component.translatable("text.hsn-optimizations.config.entity_culling"),
						cfg.entityCullingEnabled)
				.setDefaultValue(true)
				.setSaveConsumer(v -> cfg.entityCullingEnabled = v)
				.build());

		entities.addEntry(entry.startDoubleField(
						Component.translatable("text.hsn-optimizations.config.max_entity_distance"),
						cfg.maxEntityRenderDistance)
				.setDefaultValue(48.0)
				.setMin(8.0).setMax(256.0)
				.setSaveConsumer(v -> cfg.maxEntityRenderDistance = v)
				.build());

		entities.addEntry(entry.startDoubleField(
						Component.translatable("text.hsn-optimizations.config.max_item_distance"),
						cfg.maxItemEntityRenderDistance)
				.setDefaultValue(32.0)
				.setMin(4.0).setMax(128.0)
				.setSaveConsumer(v -> cfg.maxItemEntityRenderDistance = v)
				.build());

		entities.addEntry(entry.startDoubleField(
						Component.translatable("text.hsn-optimizations.config.max_xp_distance"),
						cfg.maxXpOrbRenderDistance)
				.setDefaultValue(24.0)
				.setMin(4.0).setMax(128.0)
				.setSaveConsumer(v -> cfg.maxXpOrbRenderDistance = v)
				.build());

		entities.addEntry(entry.startBooleanToggle(
						Component.translatable("text.hsn-optimizations.config.shadow_culling"),
						cfg.shadowCullingEnabled)
				.setDefaultValue(true)
				.setTooltip(Component.translatable("text.hsn-optimizations.config.shadow_culling.tooltip"))
				.setSaveConsumer(v -> cfg.shadowCullingEnabled = v)
				.build());

		entities.addEntry(entry.startDoubleField(
						Component.translatable("text.hsn-optimizations.config.max_shadow_distance"),
						cfg.maxShadowDistance)
				.setDefaultValue(24.0)
				.setMin(4.0).setMax(128.0)
				.setTooltip(Component.translatable("text.hsn-optimizations.config.max_shadow_distance.tooltip"))
				.setSaveConsumer(v -> cfg.maxShadowDistance = v)
				.build());

		entities.addEntry(entry.startBooleanToggle(
						Component.translatable("text.hsn-optimizations.config.disable_smooth_lighting"),
						cfg.disableSmoothLighting)
				.setDefaultValue(false)
				.setTooltip(Component.translatable("text.hsn-optimizations.config.disable_smooth_lighting.tooltip"))
				.setSaveConsumer(v -> cfg.disableSmoothLighting = v)
				.build());

		// ===== Items (server) =====
		ConfigCategory items = builder.getOrCreateCategory(
				Component.translatable("text.hsn-optimizations.config.category.items"));

		items.addEntry(entry.startBooleanToggle(
						Component.translatable("text.hsn-optimizations.config.item_merge"),
						cfg.itemMergeEnabled)
				.setDefaultValue(true)
				.setTooltip(Component.translatable("text.hsn-optimizations.config.item_merge.tooltip"))
				.setSaveConsumer(v -> cfg.itemMergeEnabled = v)
				.build());

		items.addEntry(entry.startIntSlider(
						Component.translatable("text.hsn-optimizations.config.item_merge_interval"),
						cfg.itemMergeIntervalTicks, 10, 200)
				.setDefaultValue(40)
				.setSaveConsumer(v -> cfg.itemMergeIntervalTicks = v)
				.build());

		items.addEntry(entry.startDoubleField(
						Component.translatable("text.hsn-optimizations.config.item_merge_radius"),
						cfg.itemMergeRadius)
				.setDefaultValue(2.0)
				.setMin(0.5).setMax(8.0)
				.setSaveConsumer(v -> cfg.itemMergeRadius = v)
				.build());

		// ===== Memory =====
		ConfigCategory memory = builder.getOrCreateCategory(
				Component.translatable("text.hsn-optimizations.config.category.memory"));

		memory.addEntry(entry.startBooleanToggle(
						Component.translatable("text.hsn-optimizations.config.idle_trim"),
						cfg.idleMemoryTrimEnabled)
				.setDefaultValue(false)
				.setTooltip(Component.translatable("text.hsn-optimizations.config.idle_trim.tooltip"))
				.setSaveConsumer(v -> cfg.idleMemoryTrimEnabled = v)
				.build());

		memory.addEntry(entry.startIntSlider(
						Component.translatable("text.hsn-optimizations.config.idle_seconds"),
						cfg.idleSecondsBeforeTrim, 30, 600)
				.setDefaultValue(120)
				.setSaveConsumer(v -> cfg.idleSecondsBeforeTrim = v)
				.build());

		memory.addEntry(entry.startIntSlider(
						Component.translatable("text.hsn-optimizations.config.trim_cooldown"),
						cfg.memoryTrimCooldownSeconds, 60, 900)
				.setDefaultValue(300)
				.setSaveConsumer(v -> cfg.memoryTrimCooldownSeconds = v)
				.build());

		memory.addEntry(entry.startBooleanToggle(
						Component.translatable("text.hsn-optimizations.config.adaptive_ram"),
						cfg.adaptiveRamEnabled)
				.setDefaultValue(true)
				.setTooltip(Component.translatable("text.hsn-optimizations.config.adaptive_ram.tooltip"))
				.setSaveConsumer(v -> cfg.adaptiveRamEnabled = v)
				.build());

		memory.addEntry(entry.startDoubleField(
						Component.translatable("text.hsn-optimizations.config.adaptive_ram_threshold"),
						cfg.adaptiveRamThreshold)
				.setDefaultValue(0.18)
				.setMin(0.05).setMax(0.50)
				.setSaveConsumer(v -> cfg.adaptiveRamThreshold = v)
				.build());

		memory.addEntry(entry.startBooleanToggle(
						Component.translatable("text.hsn-optimizations.config.adaptive_cpu"),
						cfg.adaptiveCpuEnabled)
				.setDefaultValue(true)
				.setTooltip(Component.translatable("text.hsn-optimizations.config.adaptive_cpu.tooltip"))
				.setSaveConsumer(v -> cfg.adaptiveCpuEnabled = v)
				.build());

		memory.addEntry(entry.startDoubleField(
						Component.translatable("text.hsn-optimizations.config.adaptive_cpu_ms"),
						cfg.adaptiveCpuFrameMs)
				.setDefaultValue(40.0)
				.setMin(20.0).setMax(100.0)
				.setSaveConsumer(v -> cfg.adaptiveCpuFrameMs = v)
				.build());

		memory.addEntry(entry.startBooleanToggle(
						Component.translatable("text.hsn-optimizations.config.prefer_opengl"),
						cfg.preferOpenGl)
				.setDefaultValue(true)
				.setTooltip(Component.translatable("text.hsn-optimizations.config.prefer_opengl.tooltip"))
				.setSaveConsumer(v -> cfg.preferOpenGl = v)
				.build());

		memory.addEntry(entry.startBooleanToggle(
						Component.translatable("text.hsn-optimizations.config.auto_vanilla"),
						cfg.autoTuneVanillaGraphics)
				.setDefaultValue(true)
				.setTooltip(Component.translatable("text.hsn-optimizations.config.auto_vanilla.tooltip"))
				.setSaveConsumer(v -> cfg.autoTuneVanillaGraphics = v)
				.build());


		ConfigCategory extra = builder.getOrCreateCategory(
				Component.translatable("text.hsn-optimizations.config.category.extra"));

		extra.addEntry(entry.startBooleanToggle(
						Component.translatable("text.hsn-optimizations.config.safe_mode"),
						cfg.applySafeMode)
				.setDefaultValue(false)
				.setTooltip(Component.translatable("text.hsn-optimizations.config.safe_mode.tooltip"))
				.setSaveConsumer(v -> cfg.applySafeMode = v)
				.build());

		extra.addEntry(entry.startBooleanToggle(
						Component.literal("Sound distance culling"),
						cfg.soundDistanceCullingEnabled)
				.setDefaultValue(true)
				.setSaveConsumer(v -> cfg.soundDistanceCullingEnabled = v)
				.build());
		extra.addEntry(entry.startDoubleField(
						Component.literal("Max sound distance"),
						cfg.maxSoundDistance)
				.setDefaultValue(32.0).setMin(8.0).setMax(128.0)
				.setSaveConsumer(v -> cfg.maxSoundDistance = v)
				.build());
		extra.addEntry(entry.startBooleanToggle(
						Component.literal("Weather sound reduction"),
						cfg.weatherSoundReductionEnabled)
				.setDefaultValue(true)
				.setSaveConsumer(v -> cfg.weatherSoundReductionEnabled = v)
				.build());
		extra.addEntry(entry.startDoubleField(
						Component.literal("Weather sound keep chance"),
						cfg.weatherSoundKeepChance)
				.setDefaultValue(0.25).setMin(0.0).setMax(1.0)
				.setSaveConsumer(v -> cfg.weatherSoundKeepChance = v)
				.build());
		extra.addEntry(entry.startBooleanToggle(
						Component.literal("Strict armor stand / item frame distance"),
						cfg.decorationEntityStrictDistance)
				.setDefaultValue(true)
				.setSaveConsumer(v -> cfg.decorationEntityStrictDistance = v)
				.build());
		extra.addEntry(entry.startDoubleField(
						Component.literal("Max decoration entity distance"),
						cfg.maxDecorationEntityDistance)
				.setDefaultValue(24.0).setMin(4.0).setMax(128.0)
				.setSaveConsumer(v -> cfg.maxDecorationEntityDistance = v)
				.build());
		extra.addEntry(entry.startBooleanToggle(
						Component.literal("Beacon beam distance cull"),
						cfg.beaconBeamCullingEnabled)
				.setDefaultValue(true)
				.setSaveConsumer(v -> cfg.beaconBeamCullingEnabled = v)
				.build());
		extra.addEntry(entry.startDoubleField(
						Component.literal("Max beacon beam distance"),
						cfg.maxBeaconBeamDistance)
				.setDefaultValue(48.0).setMin(8.0).setMax(256.0)
				.setSaveConsumer(v -> cfg.maxBeaconBeamDistance = v)
				.build());
		extra.addEntry(entry.startBooleanToggle(
						Component.literal("Limit toasts / popups"),
						cfg.toastLimitEnabled)
				.setDefaultValue(true)
				.setSaveConsumer(v -> cfg.toastLimitEnabled = v)
				.build());
		extra.addEntry(entry.startIntSlider(
						Component.literal("Max toasts"),
						cfg.maxToasts, 1, 10)
				.setDefaultValue(3)
				.setSaveConsumer(v -> cfg.maxToasts = v)
				.build());
		extra.addEntry(entry.startBooleanToggle(
						Component.literal("Extra biome particle cull"),
						cfg.biomeParticleExtraCullEnabled)
				.setDefaultValue(true)
				.setSaveConsumer(v -> cfg.biomeParticleExtraCullEnabled = v)
				.build());
		extra.addEntry(entry.startDoubleField(
						Component.literal("Biome particle keep chance"),
						cfg.biomeParticleKeepChance)
				.setDefaultValue(0.12).setMin(0.0).setMax(1.0)
				.setSaveConsumer(v -> cfg.biomeParticleKeepChance = v)
				.build());
		extra.addEntry(entry.startBooleanToggle(
						Component.literal("Show adaptive status on F3"),
						cfg.f3ShowAdaptiveStatus)
				.setDefaultValue(true)
				.setSaveConsumer(v -> cfg.f3ShowAdaptiveStatus = v)
				.build());

		extra.addEntry(entry.startBooleanToggle(
						Component.literal("Distant entity animation skip"),
						cfg.distantAnimationSkipEnabled)
				.setDefaultValue(false)
				.setTooltip(Component.literal("OFF by default. When ON, far non-player living entities tick less often on the client (saves CPU; may look choppy)."))
				.setSaveConsumer(v -> cfg.distantAnimationSkipEnabled = v)
				.build());
		extra.addEntry(entry.startDoubleField(
						Component.literal("Distant animation distance"),
						cfg.distantAnimationDistance)
				.setDefaultValue(24.0).setMin(8.0).setMax(128.0)
				.setSaveConsumer(v -> cfg.distantAnimationDistance = v)
				.build());
		extra.addEntry(entry.startIntSlider(
						Component.literal("Distant tick interval"),
						cfg.distantAnimationTickInterval, 2, 5)
				.setDefaultValue(2)
				.setTooltip(Component.literal("2 = half rate, 3 = one-third rate, etc."))
				.setSaveConsumer(v -> cfg.distantAnimationTickInterval = v)
				.build());

		return builder.build();

	}
}
