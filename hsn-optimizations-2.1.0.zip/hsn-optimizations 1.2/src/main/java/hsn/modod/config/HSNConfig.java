package hsn.modod.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import hsn.modod.HSNOptimizations;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * All tunable settings for HSN-Optimizations.
 * Persisted as JSON under config/hsn-optimizations.json.
 * Edited in-game via Cloth Config (Mod Menu).
 */
public class HSNConfig {

	public enum Preset {
		ULTRA_LOW,   // max FPS, pre-2016 / Intel HD 4000-class
		LOW,         // low-end laptops / integrated GPUs
		BALANCED,    // default-ish, good for most machines
		QUALITY,     // light culling only
		CUSTOM       // user-tuned values; selecting this does nothing
	}

	// ----- Particles -----
	public boolean particleCullingEnabled = true;
	public int maxParticles = 700;
	public double maxParticleDistance = 24.0;
	public double rainKeepChance = 0.18;   // 0..1
	public double smokeKeepChance = 0.25;  // 0..1

	// ----- Entity render culling -----
	public boolean entityCullingEnabled = true;
	public double maxEntityRenderDistance = 48.0;
	public double maxItemEntityRenderDistance = 32.0;
	public double maxXpOrbRenderDistance = 24.0;

	// ----- Shadows & lighting -----
	public boolean shadowCullingEnabled = true;
	public double maxShadowDistance = 24.0;
	/** When true, forces vanilla smooth lighting (ambient occlusion) off for FPS. */
	public boolean disableSmoothLighting = false;

	// Heavy particle keep chance (explosions, portals, etc.)
	public double heavyParticleKeepChance = 0.20;

	// ----- Item entity server-side optimisations -----
	public boolean itemMergeEnabled = true;
	public int itemMergeIntervalTicks = 40;   // every 2 seconds
	public double itemMergeRadius = 2.0;
	public int maxItemEntitiesPerChunkScan = 64;

	// ----- Memory / idle GC (client, opt-in) -----
	public boolean idleMemoryTrimEnabled = false;
	public int idleSecondsBeforeTrim = 120;
	public int memoryTrimCooldownSeconds = 300;

	// ----- Adaptive RAM / CPU (client) -----
	/** When free heap is low, temporarily tighten particle/shadow limits. */
	public boolean adaptiveRamEnabled = true;
	/** Free-heap ratio (0..1) below which adaptive mode engages. */
	public double adaptiveRamThreshold = 0.18;
	/** Extra particle reduction factor while adaptive (0.5 = half cap). */
	public double adaptiveParticleFactor = 0.45;
	/** When frame time is high, further reduce particles (CPU relief). */
	public boolean adaptiveCpuEnabled = true;
	/** Frame time in ms above which CPU adaptive engages. */
	public double adaptiveCpuFrameMs = 40.0;

	/** Prefer OpenGL in options.txt (avoid unstable Vulkan on old iGPUs). */
	public boolean preferOpenGl = true;
	/** Once per session: clouds off, particles minimal, bobbing off. */
	public boolean autoTuneVanillaGraphics = true;

	// ----- Variable / progressive render distance -----
	public boolean variableRenderDistanceEnabled = false; // removed feature — left for old JSON only
	/** Ceiling for the ramp (chunks). Default 15 for weak GPUs. */
	public int variableRenderDistanceMax = 15;
	/** Minimum FPS required before climbing to the next step. */
	public int variableRenderDistanceMinFps = 28;
	/** Ticks between FPS checks (20 = 1s). */
	public int variableRenderDistanceStepTicks = 40;
	/** How long FPS must stay healthy before one step up. */
	public int variableRenderDistanceStableTicks = 60;

	// ----- Light-style particles (not full light engine) -----
	public boolean lightParticleCullingEnabled = true;
	public double lightParticleKeepChance = 0.15;

	// ----- Extra low-end (safe) -----
	/** Cull far game sounds (non-UI). */
	public boolean soundDistanceCullingEnabled = true;
	public double maxSoundDistance = 32.0;
	/** Extra reduction for rain/thunder weather sounds. */
	public boolean weatherSoundReductionEnabled = true;
	public double weatherSoundKeepChance = 0.25;
	/** Stricter render distance for armor stands & item frames. */
	public boolean decorationEntityStrictDistance = true;
	public double maxDecorationEntityDistance = 24.0;
	/** Limit beacon beam rendering distance. */
	public boolean beaconBeamCullingEnabled = true;
	public double maxBeaconBeamDistance = 48.0;
	/** Cap toast / popup spam. */
	public boolean toastLimitEnabled = true;
	public int maxToasts = 3;
	/** Extra cull for biome ambient particles (spore, ash, drip…). */
	public boolean biomeParticleExtraCullEnabled = true;
	public double biomeParticleKeepChance = 0.12;
	/** One-click ultra-safe pack on save when checked. */
	public boolean applySafeMode = false;
	/** Show adaptive RAM/CPU status on F3. */
	public boolean f3ShowAdaptiveStatus = true;

	/** Client: slow tick/animation updates for far living entities (toggleable). */
	public boolean distantAnimationSkipEnabled = false;
	/** Distance beyond which skip may apply. */
	public double distantAnimationDistance = 24.0;
	/** Only run entity client tick every N ticks when far (2 = half rate). */
	public int distantAnimationTickInterval = 2;

	// ----- Preset control -----
	public Preset lastAppliedPreset = Preset.ULTRA_LOW;
	/** Check this box and save to apply the selected preset values. */
	public boolean applySelectedPreset = false;

	// ----- Runtime helpers (not serialised meaningfully) -----
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path CONFIG_PATH = FabricLoader.getInstance()
			.getConfigDir().resolve("hsn-optimizations.json");

	private static HSNConfig INSTANCE;

	public static HSNConfig get() {
		if (INSTANCE == null) {
			INSTANCE = load();
		}
		return INSTANCE;
	}

	public static HSNConfig load() {
		if (Files.exists(CONFIG_PATH)) {
			try {
				String json = Files.readString(CONFIG_PATH);
				HSNConfig cfg = GSON.fromJson(json, HSNConfig.class);
				if (cfg != null) {
					INSTANCE = cfg;
					HSNOptimizations.LOGGER.info("Loaded config from {}", CONFIG_PATH);
					return cfg;
				}
			} catch (Exception e) {
				HSNOptimizations.LOGGER.warn("Failed to load config, using defaults: {}", e.toString());
			}
		}
		INSTANCE = new HSNConfig();
		// First run: apply ultra-low defaults explicitly
		HSNPresets.apply(INSTANCE, Preset.ULTRA_LOW);
		INSTANCE.save();
		return INSTANCE;
	}

	public void save() {
		try {
			Files.createDirectories(CONFIG_PATH.getParent());
			Files.writeString(CONFIG_PATH, GSON.toJson(this));
		} catch (IOException e) {
			HSNOptimizations.LOGGER.error("Failed to save config: {}", e.toString());
		}
	}

	/** Called after the Cloth Config screen saves. */
	public void onSaved() {
		if (applySafeMode) {
			applySafeModeDefaults();
			applySafeMode = false;
			lastAppliedPreset = Preset.ULTRA_LOW;
			save();
			HSNOptimizations.LOGGER.info("Applied SAFE MODE (ultra-low pack)");
			return;
		}
		if (applySelectedPreset && lastAppliedPreset != Preset.CUSTOM) {
			HSNPresets.apply(this, lastAppliedPreset);
			applySelectedPreset = false;
			save();
			HSNOptimizations.LOGGER.info("Applied preset: {}", lastAppliedPreset);
		} else {
			lastAppliedPreset = Preset.CUSTOM;
			save();
		}
	}

	/** Hard pack for barely-runnable PCs. */
	public void applySafeModeDefaults() {
		particleCullingEnabled = true;
		maxParticles = 400;
		maxParticleDistance = 16.0;
		rainKeepChance = 0.08;
		smokeKeepChance = 0.12;
		heavyParticleKeepChance = 0.10;
		lightParticleCullingEnabled = true;
		lightParticleKeepChance = 0.08;
		biomeParticleExtraCullEnabled = true;
		biomeParticleKeepChance = 0.08;
		entityCullingEnabled = true;
		maxEntityRenderDistance = 32.0;
		maxItemEntityRenderDistance = 20.0;
		maxXpOrbRenderDistance = 16.0;
		decorationEntityStrictDistance = true;
		maxDecorationEntityDistance = 16.0;
		shadowCullingEnabled = true;
		maxShadowDistance = 12.0;
		disableSmoothLighting = true;
		soundDistanceCullingEnabled = true;
		maxSoundDistance = 24.0;
		weatherSoundReductionEnabled = true;
		weatherSoundKeepChance = 0.15;
		beaconBeamCullingEnabled = true;
		maxBeaconBeamDistance = 32.0;
		toastLimitEnabled = true;
		maxToasts = 2;
		variableRenderDistanceEnabled = true;
		variableRenderDistanceMax = 10;
		variableRenderDistanceMinFps = 25;
		adaptiveRamEnabled = true;
		adaptiveCpuEnabled = true;
		preferOpenGl = true;
		autoTuneVanillaGraphics = true;
		distantAnimationSkipEnabled = true;
		distantAnimationDistance = 20.0;
		distantAnimationTickInterval = 3;
	}

	// Squared distances for fast cull checks
	public double maxParticleDistanceSq() {
		return maxParticleDistance * maxParticleDistance;
	}

	public double maxEntityRenderDistanceSq() {
		return maxEntityRenderDistance * maxEntityRenderDistance;
	}

	public double maxItemEntityRenderDistanceSq() {
		return maxItemEntityRenderDistance * maxItemEntityRenderDistance;
	}

	public double maxXpOrbRenderDistanceSq() {
		return maxXpOrbRenderDistance * maxXpOrbRenderDistance;
	}

	public double maxShadowDistanceSq() {
		return maxShadowDistance * maxShadowDistance;
	}

	public double maxSoundDistanceSq() {
		return maxSoundDistance * maxSoundDistance;
	}

	public double maxDecorationEntityDistanceSq() {
		return maxDecorationEntityDistance * maxDecorationEntityDistance;
	}

	public double maxBeaconBeamDistanceSq() {
		return maxBeaconBeamDistance * maxBeaconBeamDistance;
	}

	public double distantAnimationDistanceSq() {
		return distantAnimationDistance * distantAnimationDistance;
	}
}

