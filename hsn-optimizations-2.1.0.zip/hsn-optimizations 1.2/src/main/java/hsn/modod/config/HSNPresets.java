package hsn.modod.config;

import hsn.modod.config.HSNConfig.Preset;

/**
 * Named performance profiles. Selecting a preset overwrites the numeric fields.
 */
public final class HSNPresets {

	private HSNPresets() {}

	public static void apply(HSNConfig c, Preset preset) {
		switch (preset) {
			case ULTRA_LOW -> {
				c.particleCullingEnabled = true;
				c.maxParticles = 400;
				c.maxParticleDistance = 16.0;
				c.rainKeepChance = 0.10;
				c.smokeKeepChance = 0.12;
				c.heavyParticleKeepChance = 0.08;

				c.entityCullingEnabled = true;
				c.maxEntityRenderDistance = 32.0;
				c.maxItemEntityRenderDistance = 20.0;
				c.maxXpOrbRenderDistance = 16.0;

				c.shadowCullingEnabled = true;
				c.maxShadowDistance = 12.0;
				c.disableSmoothLighting = true;

				c.adaptiveRamEnabled = true;
				c.adaptiveCpuEnabled = true;
				c.lightParticleCullingEnabled = true;
				c.lightParticleKeepChance = 0.08;
				c.preferOpenGl = true;
				c.autoTuneVanillaGraphics = true;
				c.variableRenderDistanceEnabled = true;
				c.variableRenderDistanceMax = 12;
				c.variableRenderDistanceMinFps = 25;

				c.itemMergeEnabled = true;
				c.itemMergeIntervalTicks = 20;
				c.itemMergeRadius = 2.5;

				c.idleMemoryTrimEnabled = true;
				c.idleSecondsBeforeTrim = 90;
				c.memoryTrimCooldownSeconds = 180;
			}
			case LOW -> {
				c.particleCullingEnabled = true;
				c.maxParticles = 700;
				c.maxParticleDistance = 24.0;
				c.rainKeepChance = 0.18;
				c.smokeKeepChance = 0.25;
				c.heavyParticleKeepChance = 0.20;

				c.entityCullingEnabled = true;
				c.maxEntityRenderDistance = 48.0;
				c.maxItemEntityRenderDistance = 32.0;
				c.maxXpOrbRenderDistance = 24.0;

				c.shadowCullingEnabled = true;
				c.maxShadowDistance = 24.0;
				c.disableSmoothLighting = false;

				c.adaptiveRamEnabled = true;
				c.adaptiveCpuEnabled = true;
				c.lightParticleCullingEnabled = true;
				c.lightParticleKeepChance = 0.15;
				c.variableRenderDistanceEnabled = true;
				c.variableRenderDistanceMax = 15;
				c.variableRenderDistanceMinFps = 28;

				c.itemMergeEnabled = true;
				c.itemMergeIntervalTicks = 40;
				c.itemMergeRadius = 2.0;

				c.idleMemoryTrimEnabled = false;
				c.idleSecondsBeforeTrim = 120;
				c.memoryTrimCooldownSeconds = 300;
			}
			case BALANCED -> {
				c.particleCullingEnabled = true;
				c.maxParticles = 1500;
				c.maxParticleDistance = 48.0;
				c.rainKeepChance = 0.40;
				c.smokeKeepChance = 0.50;
				c.heavyParticleKeepChance = 0.45;

				c.entityCullingEnabled = true;
				c.maxEntityRenderDistance = 80.0;
				c.maxItemEntityRenderDistance = 48.0;
				c.maxXpOrbRenderDistance = 40.0;

				c.shadowCullingEnabled = true;
				c.maxShadowDistance = 48.0;
				c.disableSmoothLighting = false;

				c.itemMergeEnabled = true;
				c.itemMergeIntervalTicks = 60;
				c.itemMergeRadius = 1.5;

				c.idleMemoryTrimEnabled = false;
				c.idleSecondsBeforeTrim = 180;
				c.memoryTrimCooldownSeconds = 300;
			}
			case QUALITY -> {
				c.particleCullingEnabled = true;
				c.maxParticles = 4000;
				c.maxParticleDistance = 96.0;
				c.rainKeepChance = 0.80;
				c.smokeKeepChance = 0.85;
				c.heavyParticleKeepChance = 0.85;

				c.entityCullingEnabled = true;
				c.maxEntityRenderDistance = 128.0;
				c.maxItemEntityRenderDistance = 96.0;
				c.maxXpOrbRenderDistance = 64.0;

				c.shadowCullingEnabled = true;
				c.maxShadowDistance = 96.0;
				c.disableSmoothLighting = false;

				c.itemMergeEnabled = false;
				c.itemMergeIntervalTicks = 80;
				c.itemMergeRadius = 1.0;

				c.idleMemoryTrimEnabled = false;
				c.idleSecondsBeforeTrim = 300;
				c.memoryTrimCooldownSeconds = 600;
			}
			case CUSTOM -> {
				// no-op: keep current values
			}
		}
		c.lastAppliedPreset = preset;
		c.applySelectedPreset = false;
	}
}
