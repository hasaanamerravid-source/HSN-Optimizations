# HSN-Optimizations 1.9.0

**Minecraft:** 26.2 (Java Edition)  
**Loader:** Fabric  
**Focus:** PCs and laptops with hardware from **before ~2015** (Intel HD 4000 / 4600, similar AMD APUs, 4–8 GB RAM) that struggle to run modern Minecraft.

## What this mod is

A **client-focused performance addon**. It does **not** replace Sodium or C2ME.  
It cuts work that hits weak GPUs and small heaps hardest: particles, far entities, shadows, and optional adaptive limits when RAM or frame time is bad.

## Features

### Rendering load
- Particle hard cap + distance cull
- Extra reduction for rain, smoke, explosions, portals, fireworks, ash, spores
- “Light-style” particle cull (glow, flame, end rod, soul, firefly…)
- Entity / item / XP orb render distance cull (raise distance on SMP)
- Entity **shadow** distance cull
- Optional disable smooth lighting (AO)

### Adaptive systems
- **Adaptive RAM** — tightens particle/shadow limits when free heap is low
- **Adaptive CPU** — tightens further when frame time is high
- Optional idle memory trim (GC only after AFK)

### Classic config hub
- Left sidebar categories
- Default **About / README** intro screen
- Click a category to open its settings

### Variable render distance
- Toggle in Mod Menu
- On world/server join: RD starts at **2**, then climbs **2 → 3 → 5 → 8 → 10 → 12 → 15** (up to your max)
- Only increases while **FPS ≥ threshold** (default 28)
- Default max **15** chunks (configurable 2–32)
- Holds steady if FPS drops

### Low-end bootstrap
- **Prefer OpenGL** in `options.txt` (avoids flaky experimental Vulkan on old iGPUs)
- **Auto-tune vanilla graphics** once per session: clouds OFF, particles MINIMAL, bobbing OFF
- Presets: ULTRA_LOW / LOW / BALANCED / QUALITY / CUSTOM
- Mod Menu + Cloth Config UI
- F3 line: e.g. `HSN-Optimizations 1.9.0 + Sodium`
- Detects Sodium / Embeddium / C2ME (coexistence only)

### Server-side (light)
- Nearby identical item-entity merge (public API, configurable)

## Recommended stack for pre-2015 hardware

1. Fabric Loader + Fabric API  
2. **Sodium** 0.9.x (OpenGL, not Vulkan if unstable)  
3. **HSN-Optimizations** (this mod) — ULTRA_LOW or LOW preset  
4. **Lithium** + **FerriteCore** (if available for 26.2)  
5. **C2ME** for chunk generation (optional but helpful)  
6. JVM args from `scripts/jvm-ultralow.txt` (4 GB) or `jvm-low.txt` (8 GB)  
7. **No Iris shaders** on Intel HD 4000-class (too heavy)

## SMP / PvP note

Entity distance culling can hide far players.  
Use BALANCED/QUALITY, set max entity distance to **80–128**, or disable entity culling on PvP servers.

## What this mod does NOT do

- Not a Sodium / Embeddium replacement  
- Not a C2ME replacement  
- Not a full light-engine rewrite  
- Does not force DirectX (Java Edition cannot use DirectX)  
- Does not hard-force OpenGL 4.6 (would crash GPUs that only have 4.3)

## Build

```bash
./gradlew build
```

Output: `build/libs/hsn-optimizations-1.9.0.jar`

## Config

- In-game: Mods → HSN-Optimizations  
- File: `config/hsn-optimizations.json`  
- JVM guides: `JVM_ARGS.md` and `scripts/`

## License

See `LICENSE` in the project root.
