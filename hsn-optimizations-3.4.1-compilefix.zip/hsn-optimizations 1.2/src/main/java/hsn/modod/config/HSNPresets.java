package hsn.modod.config;

import hsn.modod.config.HSNConfig.Preset;

/** Named performance profiles — ULTRA_LOW is the max-FPS pack. */
public final class HSNPresets {

	private HSNPresets() {}

	public static void apply(HSNConfig c, Preset preset) {
		switch (preset) {
			case ULTRA_LOW -> {
				c.particleCullingEnabled = true;
				c.maxParticles = 280;
				c.maxParticleDistance = 12.0;
				c.rainKeepChance = 0.04;
				c.smokeKeepChance = 0.08;
				c.heavyParticleKeepChance = 0.05;
				c.biomeParticleExtraCullEnabled = true;
				c.biomeParticleKeepChance = 0.04;
				c.lightParticleCullingEnabled = true;
				c.lightParticleKeepChance = 0.04;

				c.entityCullingEnabled = true;
				c.maxEntityRenderDistance = 24.0;
				c.maxItemEntityRenderDistance = 14.0;
				c.maxXpOrbRenderDistance = 12.0;
				c.decorationEntityStrictDistance = true;
				c.maxDecorationEntityDistance = 12.0;

				c.shadowCullingEnabled = true;
				c.maxShadowDistance = 8.0;
				c.disableSmoothLighting = true;

				c.soundDistanceCullingEnabled = true;
				c.maxSoundDistance = 18.0;
				c.weatherSoundReductionEnabled = true;
				c.weatherSoundKeepChance = 0.08;
				c.toastLimitEnabled = true;
				c.maxToasts = 1;

				c.blockEntityCullingEnabled = true;
				c.maxBlockEntityRenderDistance = 18.0;
				c.colorCacheEnabled = true;
				c.fpsQualityLadderEnabled = true;
				c.fpsLadderLowThreshold = 40;
				c.fpsLadderHighThreshold = 60;
				c.reduceCloudsEnabled = true;
				c.reduceSkyEffectsEnabled = true;

				c.adaptiveRamEnabled = true;
				c.adaptiveCpuEnabled = true;
				c.adaptiveRamThreshold = 0.22;
				c.adaptiveCpuFrameMs = 28.0;
				c.preferOpenGl = true;
				c.autoTuneVanillaGraphics = true;

				c.distantAnimationSkipEnabled = true;
				c.distantAnimationDistance = 16.0;
				c.distantAnimationTickInterval = 3;

				c.itemMergeEnabled = true;
				c.itemMergeIntervalTicks = 15;
				c.itemMergeRadius = 3.0;
				c.idleMemoryTrimEnabled = true;
				c.idleSecondsBeforeTrim = 60;

				c.hardcoreExpEnabled = false;
				c.variableRenderDistanceEnabled = false;
			}
			case LOW -> {
				c.particleCullingEnabled = true;
				c.maxParticles = 500;
				c.maxParticleDistance = 18.0;
				c.rainKeepChance = 0.10;
				c.smokeKeepChance = 0.15;
				c.heavyParticleKeepChance = 0.12;
				c.entityCullingEnabled = true;
				c.maxEntityRenderDistance = 36.0;
				c.maxItemEntityRenderDistance = 22.0;
				c.maxXpOrbRenderDistance = 16.0;
				c.shadowCullingEnabled = true;
				c.maxShadowDistance = 14.0;
				c.disableSmoothLighting = true;
				c.blockEntityCullingEnabled = true;
				c.maxBlockEntityRenderDistance = 28.0;
				c.colorCacheEnabled = true;
				c.fpsQualityLadderEnabled = true;
				c.adaptiveRamEnabled = true;
				c.adaptiveCpuEnabled = true;
				c.preferOpenGl = true;
				c.autoTuneVanillaGraphics = true;
				c.hardcoreExpEnabled = false;
				c.variableRenderDistanceEnabled = false;
			}
			case BALANCED -> {
				c.particleCullingEnabled = true;
				c.maxParticles = 1200;
				c.maxParticleDistance = 40.0;
				c.rainKeepChance = 0.35;
				c.smokeKeepChance = 0.45;
				c.entityCullingEnabled = true;
				c.maxEntityRenderDistance = 64.0;
				c.shadowCullingEnabled = true;
				c.maxShadowDistance = 32.0;
				c.disableSmoothLighting = false;
				c.blockEntityCullingEnabled = true;
				c.maxBlockEntityRenderDistance = 48.0;
				c.colorCacheEnabled = true;
				c.fpsQualityLadderEnabled = true;
				c.distantAnimationSkipEnabled = false;
				c.hardcoreExpEnabled = false;
			}
			case QUALITY -> {
				c.particleCullingEnabled = true;
				c.maxParticles = 2500;
				c.maxParticleDistance = 64.0;
				c.rainKeepChance = 0.7;
				c.smokeKeepChance = 0.8;
				c.entityCullingEnabled = true;
				c.maxEntityRenderDistance = 96.0;
				c.shadowCullingEnabled = true;
				c.maxShadowDistance = 64.0;
				c.disableSmoothLighting = false;
				c.blockEntityCullingEnabled = false;
				c.fpsQualityLadderEnabled = false;
				c.distantAnimationSkipEnabled = false;
				c.hardcoreExpEnabled = false;
			}
			case CUSTOM -> {}
		}
		c.lastAppliedPreset = preset;
	}
}
